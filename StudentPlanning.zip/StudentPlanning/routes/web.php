<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\EnseignantController;
use App\Http\Controllers\PageAccueilController;
use App\Http\Controllers\GestionnaireController;
use App\Http\Controllers\RegisterUserController;
use App\Http\Controllers\AuthenticatedSessionController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



// ------------------------------------- //
// Route principale pour accéder au site //
// ------------------------------------- //

// Page principale du projet
Route::get('/', [PageAccueilController::class,'pageAccueil'])->name('index');  

// Connexion de l'utilisateur
Route::get('/login', [AuthenticatedSessionController::class,'showForm'])->name('login');
Route::post('/login', [AuthenticatedSessionController::class,'login']);

// Deconnexion de l'utilisateur
Route::get('/logout', [AuthenticatedSessionController::class,'logout'])->name('logout')->middleware('auth');

// L'enregistrement
Route::get('/register', [RegisterUserController::class,'registerForm'])->name('register');
Route::post('/register', [RegisterUserController::class,'register']);

// Changement de mot de passe
Route::get('changementMDP',[RegisterUserController::class,'changementForm']) -> name('updateform')->middleware('auth');
Route::post('changementMDP',[RegisterUserController::class,'update']) -> name('update')->middleware('auth');

// Formulaire de modification du nom/prenom
Route::get('changementNomPrenom',[RegisterUserController::class,'modifForm'])->name('modifNomPrenomForm')->middleware('auth');

// Modification du nom/prenom
Route::post('changementNomPrenom',[RegisterUserController::class,'modif'])->name('modifNomPrenom')->middleware('auth');

// Profil d'utilisateur
Route::get('profil',[PageAccueilController::class,'profil'])->name('profil')->middleware('auth');

// ----------------- //
// Route Enseignants //
// ----------------- //

// Liste des cours à l'utilisateur connecté
Route::get('enseignant/liste/cours/associe',[EnseignantController::class,'listeEnseignantCours'])->name('listeEnseignantCours')->middleware('is_enseignant');

// Liste des etudiants inscrits dans un cours
Route::get('enseignant/liste/cours/inscrits/{cours_id}',[EnseignantController::class,'listeInscritCours'])->name('listeInscritCours')->middleware('is_enseignant');

// Liste des séances d'un cours
Route::get('enseignant/liste/seance/{cours_id}',[EnseignantController::class,'pointageEtudiantSeance'])->name('pointageEtudiantSeance')->middleware('is_enseignant');

// Pointage d'un étudiant individuellement
Route::get('enseignant/{seance_id}/associe/{etudiant_id}',[EnseignantController::class,'pointageEtudiantSeanceVrai'])->name('pointageEtudiantSeanceVrai')->middleware('is_enseignant');

// Liste des présences de la table présence
Route::get('enseignant/liste/des/presences',[EnseignantController::class,'listeDesPresences'])->name('listeDesPresences')->middleware('is_enseignant');

// Panier qui contiendras tout les pointages
Route::get('enseignant/pointage/multiple/{cours_id}/{etudiant_id}',[EnseignantController::class,'pointageEtudiantsMultipleSeance'])->name('pointageEtudiantsMultipleSeance')->middleware('is_enseignant');

// Formulaire de confirmation des pointages
Route::get('enseignant/pointage/multiple/ajout/etudiant/{cours_id}',[EnseignantController::class,'ajoutPanierDansPointageConfirmation'])->name('ajoutPanierDansPointageConfirmation')->middleware('is_enseignant');

// Application de tout les pointages multiples et les met dans la table présence
Route::post('enseignant/pointage/multiple/ajout/etudiant/{cours_id}',[EnseignantController::class,'ajoutPanierDansPointage'])->name('ajoutPanierDansPointage')->middleware('is_enseignant');

// Liste des présents/absent par séance choisie
Route::get('enseignant/liste/present/absent/{cours_id}/{seance_id}',[EnseignantController::class,'listePresentAbsentSeance'])->name('listePresentAbsentSeance')->middleware('is_enseignant');

// Totaux de présence
Route::get('enseignant/liste/totaux/de/presence/{cours_id}',[EnseignantController::class,'totalPresenceCours'])->name('totalPresenceCours')->middleware('is_enseignant');

// ------------------- //
// Route Gestionnaires //
// ------------------- //

// Formulaire d'ajout d'un étudiant
Route::get('gestionnaire/ajout/etudiant',[GestionnaireController::class,'ajoutEtudiantForm'])->name('ajoutEtudiantForm')->middleware('is_gestionnaire');

// Ajout d'un étudiant
Route::post('gestionnaire/ajout/etudiant',[GestionnaireController::class,'ajoutEtudiant'])->name('ajoutEtudiant')->middleware('is_gestionnaire');

// Formulaire de mise à jour de l'étudiants
Route::get('gestionnaire/gestion/etudiants/{id}',[GestionnaireController::class,'miseAJourEtudiantForm'])->name('miseAJourEtudiantForm')->middleware('is_gestionnaire');

// Mise à jour de l'étudiant
Route::post('gestionnaire/gestion/etudiants/{id}',[GestionnaireController::class,'miseAJourEtudiant'])->name('miseAJourEtudiant')->middleware('is_gestionnaire');

// Formulaire de suppresion d'un étudiant
Route::get('gestionnaire/suppression/etudiants/{id}',[GestionnaireController::class,'suppEtudiantForm'])->name('suppEtudiantForm')->middleware('is_gestionnaire');

// Suppresion d'un étudiant
Route::post('gestionnaire/suppression/etudiants/{id}',[GestionnaireController::class,'suppEtudiant'])->name('suppEtudiant')->middleware('is_gestionnaire');

// Formulaire de création d'une nouvelle séance de cours
Route::get('gestionnaire/create/seance/cours/{id}',[GestionnaireController::class,'createNewSeanceCoursForm'])->name('createNewSeanceForm')->middleware('is_gestionnaire');

// Création d'une nouvelle séance de cours
Route::post('gestionnaire/create/seance/cours/{id}',[GestionnaireController::class,'createNewSeanceCours'])->name('createNewSeanceCour')->middleware('is_gestionnaire');

// Formulaire de mise a jour des seances
Route::get('gestionnaire/miseAJour/seance/{id}',[GestionnaireController::class,'miseAJourSeanceForm'])->name('miseAJourSeanceForm')->middleware('is_gestionnaire');

// Mise a jour des seances
Route::post('gestionnaire/miseAJour/seance/{id}',[GestionnaireController::class,'miseAJourSeanceCours'])->name('miseAJourSeanceCours')->middleware('is_gestionnaire');

// Formulaire de suppression des seances de cours 
Route::get('gestionnaire/suppression/seance/{id}',[GestionnaireController::class,'suppSeanceForm'])->name('suppSeanceForm')->middleware('is_gestionnaire');

// Suppression des seances de cours 
Route::post('gestionnaire/suppression/seance/{id}',[GestionnaireController::class,'suppSeanceCours'])->name('suppSeanceCours')->middleware('is_gestionnaire');

// Choisir un étudiant à associé
Route::get('gestionnaire/etudiants/{id}/',[GestionnaireController::class,'associationIndividuelleEtudiants'])->name('associateEtudiants')->middleware('is_gestionnaire');

// Choisit le cours qui sera associé à l'étudiant et les associe
Route::get('gestionnaire/etudiants/{id}/cours/{id2}',[GestionnaireController::class,'associationEtudiantsCours'])->name('associateEtudiantsCours')->middleware('is_gestionnaire');

// Suppression de l'association etudiant cours
Route::get('gestionnaire/liste/suppression/etudiants/associations/{cours_id}/{etudiants}',[GestionnaireController::class,'suppAssociationIndividuelleEtudiants'])->name('associationSupprimerEtudiant')->middleware('is_gestionnaire');

// Liste des étudiants associés à ce cours 
Route::get('gestionnaire/liste/associations/etudiants/{cours_id}',[GestionnaireController::class,'listeEtudiantAssociationCeCours'])->name('listeEtudiantAssociationCeCours')->middleware('is_gestionnaire');

// Cours à copier vers un autre 
Route::get('gestionnaire/liste/des/cours/copie/associations/{cours_id}',[GestionnaireController::class,'copieCours'])->name('copieCours')->middleware('is_gestionnaire');

// Application de l'association du cours copié vers un autre cours
Route::get('gestionnaire/liste/associations/cours/a/cours/{cours_id}/{cours_id1}',[GestionnaireController::class,'copieAssociationsCoursACours'])->name('copieAssociationsCoursACours')->middleware('is_gestionnaire');

// Liste des étudiants pour l'association multiple
Route::get('gestionnaire/liste/multiple/etudiants/{cours_id}',[GestionnaireController::class,'listeEtudiantPourMultiple'])->name('listeEtudiantPourMultiple')->middleware('is_gestionnaire');

// Panier contenant toutes les associations multiples
Route::get('gestionnaire/associer/multiple/{cours_id}/{etudiant_id}',[GestionnaireController::class,'associerEtudiantsMultipleCours'])->name('associerEtudiantsMultipleCours')->middleware('is_gestionnaire');

// Formulaire de confirmation des associations multiples
Route::get('gestionnaire/associer/multiple/ajout/etudiant/{cours_id}',[GestionnaireController::class,'ajoutPanierDansAssocierConfirmation'])->name('ajoutPanierDansAssocierConfirmation')->middleware('is_gestionnaire');

// Associations multiples
Route::post('gestionnaire/associer/multiple/ajout/etudiant/{cours_id}',[GestionnaireController::class,'ajoutPanierDansAssocier'])->name('ajoutPanierDansAssocier')->middleware('is_gestionnaire');

// Panier contenant toutes les dissociations multiples
Route::get('gestionnaire/dissocier/multiple/{cours_id}/{etudiant_id}',[GestionnaireController::class,'dissocierEtudiantsMultipleCours'])->name('dissocierEtudiantsMultipleCours')->middleware('is_gestionnaire');

// Formulaire de confirmation de la dissociation multiple
Route::get('gestionnaire/dissocier/multiple/suppression/etudiant/{cours_id}',[GestionnaireController::class,'ajoutPanierDansDissocierConfirmation'])->name('ajoutPanierDansDissocierConfirmation')->middleware('is_gestionnaire');

// Dissociations multiples
Route::post('gestionnaire/dissocier/multiple/suppression/etudiant/{cours_id}',[GestionnaireController::class,'ajoutPanierDansDissocier'])->name('ajoutPanierDansDissocier')->middleware('is_gestionnaire');

// Choisir un enseignants à associé
Route::get('gestionnaire/enseignants/{id}/',[GestionnaireController::class,'associationEnseignant'])->name('associationEnseignant')->middleware('is_gestionnaire');

// Choisit le cours qui sera associé à l'enseignant et les associe
Route::get('gestionnaire/enseignants/{id}/cours/{id2}',[GestionnaireController::class,'associationEnseignantsCours'])->name('associationEnseignantsCours')->middleware('is_gestionnaire');

// Suppression de l'association enseignant cours
Route::get('gestionnaire/liste/suppression/enseignants/associations/{cours_id}/{users}',[GestionnaireController::class,'suppAssociationEnseignants'])->name('associationSupprimerEnseignant')->middleware('is_gestionnaire');

// Liste des enseignants associations à ce cours 
Route::get('gestionnaire/liste/associations/enseignants/{cours_id}',[GestionnaireController::class,'listeEnseignantsAssociationCours'])->name('listeEnseignantsAssociationCours')->middleware('is_gestionnaire');

// Liste des étudiants avec pagination 
Route::get('gestionnaire/liste/etudiants',[GestionnaireController::class,'listeDesEtudiants'])->name('listeEtudiants')->middleware('is_gestionnaire');

// Recherche des étudiands
Route::get('gestionnaire/liste/recherche/nom/prenom/noet',[GestionnaireController::class,'listeEtudiantRecherche'])->name('listeEtudiantRecherche')->middleware('is_gestionnaire');

// Liste des cours
Route::get('gestionnaire/liste/cours',[GestionnaireController::class,'listeCours'])->name('listeCoursGestio')->middleware('is_gestionnaire');

// Liste des séances pour un cours pagination 
Route::get('gestionnaire/liste/seances/cours/{cours_id}',[GestionnaireController::class,'listeSeanceCours'])->name('listeSeanceCours')->middleware('is_gestionnaire');

// Listes des associations étudiant cours
Route::get('gestionnaire/liste/associations/etudiants',[GestionnaireController::class,'listeDesAssociationsEtudiantCours'])->name('listeDesAssociationsEtudiantCours')->middleware('is_gestionnaire');

// Liste de tout les cours etudiants de la table cours_etudiants
Route::get('gestionnaire/liste/cours_etudiants',[GestionnaireController::class,'listeEtudiantAssociationCours'])->name('listeEtudiantAssociationCours')->middleware('is_gestionnaire');

// Liste des enseignants
Route::get('gestionnaire/liste/des/enseignants',[GestionnaireController::class,'listeDesEnseignants'])->name('listeDesEnseignants')->middleware('is_gestionnaire');

// Liste des associations enseignants cours 
Route::get('gestionnaire/liste/associations/enseignants',[GestionnaireController::class,'listeDesAssociationsEnseignantsCours'])->name('listeDesAssociationsEnseignantsCours')->middleware('is_gestionnaire');

// Liste des séances
Route::get('gestionnaire/liste/des/seances/',[GestionnaireController::class,'listeDesSeances'])->name('listeDesSeances')->middleware('is_gestionnaire');

// Liste des présences détaillé par étudiant
Route::get('gestionnaire/liste/presence/{etudiant_id}',[GestionnaireController::class,'listePresenceDetail'])->name('listePresenceDetail')->middleware('is_gestionnaire');

// Detail de la listes des présence détaillé par étudiant
Route::get('gestionnaire/liste/presence/detail/{etudiant_id}/{cours_id}',[GestionnaireController::class,'detailEtudiant'])->name('detailEtudiant')->middleware('is_gestionnaire');

// Liste des présences des étudiants par séance
Route::get('gestionnaire/liste/presences/etudiants/seance/{seance_id}',[GestionnaireController::class,'listePresenceEtudiantsSeance'])->name('listePresenceEtudiantsSeance')->middleware('is_gestionnaire');

// Liste des présences des étudiants par cours
Route::get('gestionnaire/liste/presences/etudiants/cours/{cours_id}',[GestionnaireController::class,'listePresenceEtudiantsCours'])->name('listePresenceEtudiantsCours')->middleware('is_gestionnaire');

// -------------------- //
// Route Administrateur //
// -------------------- //

// Liste des Utilisateurs intégrale
Route::get('admin/liste/users',[AdminController::class,'listeUser'])->name('listeUser')->middleware('is_admin');

// Liste des utilisateurs filtrés par type
Route::get('admin/liste/cours/recherche/type',[AdminController::class,'listeUserTri'])->name('listeUserTri')->middleware('is_admin');

// Recherche par nom/prénom/login
Route::get('admin/liste/recherche/nom/prenom/login',[AdminController::class,'listeUserRecherche'])->name('listeUserRecherche')->middleware('is_admin');

// Validation de l'enregistrement
Route::post('admin/liste/users/validation/{id}',[AdminController::class,'validation'])->name('validation')->middleware('is_admin');

// Formulaire de création d'un utilisateur par l'admin 
Route::get('admin/create/users',[AdminController::class,'createNewUserForm'])->name('createUserForm')->middleware('is_admin');

// Création d'un utilisateur par l'admin 
Route::post('admin/create/users',[AdminController::class,'createNewUser'])->name('createUser')->middleware('is_admin');

// Formulaire de modification d'un utilisateur
Route::get('admin/liste/users/modification/{id}',[AdminController::class,'modifUserForm'])->name('modifUserForm')->middleware('is_admin');

// Modification d'un utilisateur 
Route::post('admin/liste/users/modification/{id}',[AdminController::class,'modifUser'])->name('modifUserForm')->middleware('is_admin');

// Formulaire de suppression d'un utilisateur
Route::get('admin/liste/users/suppression/{id}',[AdminController::class,'suppUserForm'])->name('suppUserForm')->middleware('is_admin');

// Suppression d'un utilisateur
Route::post('admin/liste/users/suppression/{id}',[AdminController::class,'suppUser'])->name('suppUser')->middleware('is_admin');

// Formulaire de création d'un nouveau cours
Route::get('admin/create/cours',[AdminController::class,'createCourForm'])->name('createCourForm')->middleware('is_admin');

// Création d'un nouveau cours
Route::post('admin/create/cours',[AdminController::class,'createCour'])->name('createCour')->middleware('is_admin');

// Liste des Cours
Route::get('admin/liste/cours',[AdminController::class,'listeCours'])->name('listeCours')->middleware('is_admin');

// Recherche par intitule d'un cours
Route::get('admin/liste/cours/recherche/intitule',[AdminController::class,'listeIntituleRecherche'])->name('listeIntituleRecherche')->middleware('is_admin');

// Formulaire de modification d'un cours 
Route::get('admin/liste/cours/modification/{id}',[AdminController::class,'modifCoursForm'])->name('modifCoursForm')->middleware('is_admin');

// Modification d'un cours
Route::post('admin/liste/cours/modification/{id}',[AdminController::class,'modifCours'])->name('modifCours')->middleware('is_admin');

// Formulaire de suppresion d'un cours 
Route::get('admin/liste/cours/suppression/{id}',[AdminController::class,'suppCoursForm'])->name('suppCoursForm')->middleware('is_admin');

// Suppresion d'un cours
Route::post('admin/liste/cours/suppression/{id}',[AdminController::class,'suppCours'])->name('suppCours')->middleware('is_admin');