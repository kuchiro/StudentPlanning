<?php

namespace Database\Seeders;

use App\Models\Seance;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class SeanceSeeder extends Seeder
{
    public function run() {
        Seance::factory() 
            ->count(10) 
            ->create();
    }
}
