<?php

namespace Database\Seeders;

use App\Models\Cour;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class CourSeeder extends Seeder
{
    public function run() {
        Cour::factory() 
            ->count(10) 
            ->create();
    }
}
