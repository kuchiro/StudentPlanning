<?php

namespace Database\Factories;

use App\Models\Cour;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Cour>
 */
class CourFactory extends Factory{
    protected $model = Cour::class;
        public function definition() {
            return [
                'intitule' => $this->faker->unique()->word(), 
                'created_at' => $this->faker->dateTime(),
                'updated_at' => now(),
            ]; 
        }
}
