<?php

namespace Database\Factories;

use App\Models\Seance;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Seance>
 */
class SeanceFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    protected $model = Seance::class;
    public function definition(){
        return [
            'cours_id' => 1,
            'date_debut' => $this->faker->dateTime(),
            'date_fin' => $this->faker->dateTime(),
        ];
    }
}
