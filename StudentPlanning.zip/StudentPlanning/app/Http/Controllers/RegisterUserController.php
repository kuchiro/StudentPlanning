<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class RegisterUserController extends Controller
{
    // Formulaire d'enregistrement
    public function registerForm(){
        return view('register');
    }

    // Fonction pour s'enregistrer
    public function register(Request $request){
        $request->validate([
            'nom' =>'required|alpha_dash',
            'prenom' => 'required|alpha_dash',
            'login' => 'required|string|max:255|unique:users',
            'mdp' => 'required|confirmed',
        ]);

        $user = new User(); 
        $user->nom = $request -> nom;
        $user->prenom = $request->prenom;
        $user->login = $request->login;
        $user->mdp = Hash::make($request->mdp);
        $user->save();
        session()->flash('etat','User added');
        Auth::login($user);
        return redirect(route('index'));
    }

    // Formulaire de modification du mot de passe
    public function changementForm(){
        return view('updateform');
    }

    // Modification du mot de passe
    public function update(Request $request)
    {
         $request->validate([
            'mdp' => 'required|confirmed',
        ]);
        $user = Auth::user();
        $user -> mdp = Hash::make($request->mdp_confirmation);
        $user -> save();
        return redirect()->route('index');
        }

    // Formulaire de modification d'un nom ou d'un prénom
    public function modifForm(){
        return view('modificationNomPrenomForm');
    }

    // Fonction qui modifie ou le prénom ou le nom
    public function modif(Request $request){
        $request->validate([
            'nom' => 'required|alpha_dash',
            'prenom' => 'required|alpha_dash',
        ]);
            $user = Auth::user();
            $user -> prenom = $request -> prenom;
            $user -> nom = $request -> nom;
            $user -> save();
            return redirect()->route('index');
    }
}
