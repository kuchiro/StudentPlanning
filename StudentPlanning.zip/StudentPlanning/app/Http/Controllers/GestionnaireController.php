<?php

namespace App\Http\Controllers;

use App\Models\Cour;
use App\Models\User;
use App\Models\Seance;
use App\Models\Etudiant;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;

class GestionnaireController extends Controller
{
    // --------------------- //
    // Gestion des etudiants //
    // --------------------- //

    // Formulaire d'ajout d'un etudiant 
    public function ajoutEtudiantForm(){
        return view('ajoutEtudiantForm');
    }

    // fonction qui ajoute un etudiant dans la table étudiants
    public function ajoutEtudiant(Request $request){
         $v = $request->validate(
                [
                    'nom' => 'required|alpha_dash',
                    'prenom' => 'required|alpha_dash',
                    'noet'=> 'required|digits_between:1,15',
                ]
            );
        $etudiants = new Etudiant();    
        $etudiants -> nom = $request->nom;
        $etudiants -> prenom = $request->prenom;
        $etudiants -> noet = $request -> noet;
        $etudiants -> save();
        return redirect(route('listeEtudiants'));
    }

    // Formulaire de mise à jour 
    public function miseAJourEtudiantForm($id){
        $etudiants = Etudiant::findOrFail($id);
        return view('miseAJourEtudiantForm',['etudiants'=>$etudiants]);
    }

    // Mise a jour de l'etudiant 
    public function miseAJourEtudiant(Request $request,$id){
        $v = $request->validate(
                [
                    'nom' => 'required|alpha_dash',
                    'prenom' => 'required|alpha_dash',
                    'noet'=> 'required|',
                ]
            );
        $etudiants = Etudiant::findOrFail($id);
        $etudiants -> nom = $request->nom;
        $etudiants -> prenom = $request -> prenom;
        $etudiants -> noet = $request -> noet;
        $etudiants -> touch();
        $etudiants -> save();
        return redirect(route('listeEtudiants'));
    }

    // Formulaire de suppression de l'étudiant
    public function suppEtudiantForm($id){
        $etudiants = Etudiant::findOrFail($id);
        return view('suppEtudiant',['etudiants'=>$etudiants]);
    }

    // Suppresion de l'etudiant
    public function suppEtudiant(Request $request,$id){
         if($request -> confirmation =="Oui"){
            $etudiants = Etudiant::findOrFail($id);
            $etudiants -> cours() -> detach();
            $etudiants -> seances() -> detach();
            $etudiants -> delete();
            return redirect()->route('listeEtudiants');
        } else {
            return redirect()->route('listeEtudiants');
        }
    }

    // ----------------------------- //
    // Gestion des séances des cours //
    // ----------------------------- //

    // Liste des séances
    public function listeDesSeances(){
        $seances = Seance::all();
        return view('listeDesSeances',['seances'=>$seances]);
    }

    // Formulaire de creation d'une nouvelle seance de cours
    public function createNewSeanceCoursForm($id){
        $cours = Cour::where('id',$id)->get();
        return view('createNewSeanceForm',['cours'=>$cours]);
    }

    // Creation d'une nouvelle seance de cours
    public function createNewSeanceCours(Request $request,$id){
        $v = $request->validate(
                [
                    'date_debut' => 'required|date|before:date_fin',
                    'date_fin' => 'required|date|after:date_debut',
                ]
            );
        $seances = new Seance();
        $seances -> cours_id = $id;
        $seances -> date_debut = str_replace('T',' ',$request -> date_debut);
        $seances -> date_fin =str_replace('T',' ',$request -> date_fin);
        $seances -> save();
        return redirect()->route('listeDesSeances');
    }

    // Formulaire de mise a jour d'une séance de cours 
    public function miseAJourSeanceForm($id){
        $seances = Seance::findOrFail($id);
        return view('miseAJourSeanceForm',['seances'=>$seances]);
    }

    // Mise a jour d'une seance de cours
    public function miseAJourSeanceCours(Request $request,$id){
        $v = $request->validate(
                [
                    'date_debut' => 'required|date|before:date_fin',
                    'date_fin' => 'required|date|after:date_debut',
                ]
            );
        $seances = Seance::findOrFail($id);
        //$seances -> cours_id = $request-> cours_id;
        $seances -> date_debut = str_replace('T',' ',$request -> date_debut);
        $seances -> date_fin = str_replace('T',' ',$request -> date_fin);
        $seances -> save();
        return redirect(route('listeDesSeances'));
    }

    // Formulaire de suppression d'une seance 
    public function suppSeanceForm($id){
        $seances = Seance::findOrFail($id);
        return view('suppSeance',['seances'=>$seances]);
    }

    // Suppresion d'une seance de cours
    public function suppSeanceCours(Request $request,$id){
        if($request -> confirmation =="Oui"){
            $seances = Seance::findOrFail($id);
            $seances -> etudiants() -> detach();
            $seances -> delete();
            return redirect()->route('listeDesSeances');
        } else {
            return redirect()->route('listeDesSeances');
        }
    }

    // -------------------------- //
    // Associations des étudiants //
    // -------------------------- //

    // Liste des associations des étudiants et du cours 
    public function listeDesAssociationsEtudiantCours(){
        $cours = Cour::all();
        $etudiants = Etudiant::all();
        return view('listeDesAssociationsEtudiantCours',['cours'=>$cours,'etudiants'=>$etudiants]); 
    }

    // Associer des etudiants au cours individuelle
    public function associationIndividuelleEtudiants($id){
        $etudiants = Etudiant::findOrFail($id);
        $cours = Cour::all();
        return view('associateEtudiantCours',['etudiants'=>$etudiants,'cours'=>$cours]);
    }

    // Associer l'étudiant avec le cours
    public function associationEtudiantsCours($id,$id2){
        $etudiants = Etudiant::findOrFail($id);
        $cours = Cour::findOrFail($id2);
        $etudiants -> cours() -> attach($cours);
        return redirect(route('listeDesAssociationsEtudiantCours'));
    }

    // Supprimer l'association individuelle
    public function suppAssociationIndividuelleEtudiants($cours_id,Etudiant $etudiants){
        $cours = Cour::findOrFail($cours_id);
        $etudiants -> cours() -> detach($cours);
        return redirect(route('listeDesAssociationsEtudiantCours'));
    }

    // Liste des étudiant associés au cours
    public function listeEtudiantAssociationCours(){
        $etudiants = Etudiant::all();
        $cours = Cour::all();
        return view('listeDesEtudiantsAssocie',['etudiants'=>$etudiants,'cours'=>$cours]);   
    }

    // Liste des étudiants associés a un cours 
    public function listeEtudiantAssociationCeCours($cours_id){
        $etudiants = Etudiant::all();
        $cours = Cour::where('id',$cours_id)->get();
        return view('listeDesEtudiantsAssocieAuCours',['etudiants'=>$etudiants,'cours'=>$cours]);  
    }

    // Cours à copier dans un autre
    public function copieCours($cours_id){
        $users = User::all();
        $cours = Cour::all();
        $cours_copie = Cour::where('id',$cours_id)->get();
        return view('listeDesCoursACopier',['cours'=>$cours,'users'=>$users,'cours_copie'=>$cours_copie]);
    }

    // Copier toutes les associations d'un cours vers un autre
    public function copieAssociationsCoursACours($cours_id,$cours_id1){
        $cours_copie = Cour::findOrFail($cours_id);
        $cours_associer = Cour::findOrFail($cours_id1);
        foreach($cours_copie->etudiants as $etudiant){
            foreach($cours_associer->etudiants as $etudiantverif){
                if($etudiant->id == $etudiantverif->id){
                    $cours_associer -> etudiants()->detach($etudiantverif);
                }
            }
            $etudiantverif = Etudiant::findOrFail($etudiant->id);
            $cours_associer->etudiants()->attach($etudiantverif);
        }
        return redirect(route('listeDesAssociationsEtudiantCours'));
    }

    // Liste des étudiants pour l'association multiple
    public function listeEtudiantPourMultiple($cours_id){
        $cours = Cour::findOrFail($cours_id);
        $etudiants = Etudiant::all();
        return view('listeEtudiantMultiple',['cours'=>$cours,'etudiants'=>$etudiants,'cours_id'=>$cours_id]);
    }

    // Panier qui conserve toutes les associations
    public function associerEtudiantsMultipleCours($cours_id,$etudiant_id){
        $uid = Auth::user() -> id;
        $panier = session() ->  get('panier');
        $etudiants = Etudiant::findOrFail($etudiant_id);
            $panier[$etudiant_id] = [ 
                "etudiant_nom" => $etudiants->nom,
                "etudiant_prenom" => $etudiants->prenom,
                "noet" => $etudiants-> noet,
                "etudiant_id" => $etudiants->id,
            ];
        session()->put('panier',$panier);
        return view('panier_associer',['cours_id'=>$cours_id,'etudiant_id'=>$etudiant_id]);
    }

    // Formulaire de confirmation des associations
    public function ajoutPanierDansAssocierConfirmation($cours_id){
        return view('panier_associer_confirmation',['cours_id'=>$cours_id]);
    }

    // Fonction qui applique l'association multiple et les met dans la table
    public function ajoutPanierDansAssocier(Request $request,$cours_id){ 
            $panier = session() -> get('panier');
            $cours = Cour::where('id',$cours_id)->first();
        foreach($panier as $p){
            $stock = $p["etudiant_id"];
            $etudiants = Etudiant::where('id',$stock)->get();
            $cours -> etudiants() -> attach($etudiants);
        }
        $request->session()->forget('panier');
        return redirect()->route('listeDesAssociationsEtudiantCours');
    }

    // Panier qui conserves toutes dissociations
    public function dissocierEtudiantsMultipleCours($cours_id,$etudiant_id){
        $uid = Auth::user() -> id;
        $panier = session() ->  get('panier');
        $etudiants = Etudiant::findOrFail($etudiant_id);
            $panier[$etudiant_id] = [ 
                "etudiant_nom" => $etudiants->nom,
                "etudiant_prenom" => $etudiants->prenom,
                "noet" => $etudiants-> noet,
                "etudiant_id" => $etudiants->id,
                "cours_id"=>$cours_id,
            ];
        session()->put('panier',$panier);
        return view('panier_suppression',['cours_id'=>$cours_id,'etudiant_id'=>$etudiant_id]);
    }

    // Formulaire de confirmation de la dissociation
    public function ajoutPanierDansDissocierConfirmation($cours_id){
        return view('panier_confirmation_suppression',['cours_id'=>$cours_id]);
    }
    
    // Fonction qui applique la dissociation multiple et les enleve de la table
    public function ajoutPanierDansDissocier(Request $request,$cours_id){ 
            $panier = session() -> get('panier');
            $cours = Cour::where('id',$cours_id)->first();
        foreach($panier as $p){
            $stock = $p["etudiant_id"];
            $etudiants = Etudiant::where('id',$stock)->get();
            $cours -> etudiants() -> detach($etudiants);
        }
        $request->session()->forget('panier');
        return redirect()->route('listeDesAssociationsEtudiantCours');
    }

    // ---------------------------- //
    // Associations des enseignants //
    // ---------------------------- // 

    // Liste des Enseignants 
    public function listeDesEnseignants(){
        $users = User::where('type','enseignant')->get();
        return view('listeDesEnseignants',['users'=>$users]);
    }

    // Liste des associations des enseignants et des cours 
    public function listeDesAssociationsEnseignantsCours(){
        $users = User::where('type','enseignant')->get();
        $cours = Cour::all();
        return view('listeDesAssociationsEnseignantCours',['cours'=>$cours,'users'=>$users]); 
    }

    // fonction qui choisit l'enseignant à associer
    public function associationEnseignant($id){
        $users = User::findOrFail($id);
        $cours = Cour::all();
        return view('associateEnseignantCours',['users'=>$users,'cours'=>$cours]);
    }

    // fonction qui associe l'enseignant avec le cours
    public function associationEnseignantsCours($id,$id2){
        $users = User::findOrFail($id);
        $cours = Cour::findOrFail($id2);
        $users -> cours() -> attach($cours);
        return redirect(route('listeDesAssociationsEnseignantsCours'));
    }

    // Supprimer l'association enseignant-cours
    public function suppAssociationEnseignants($cours_id,User $users){
        $cours = Cour::findOrFail($cours_id);
        $users -> cours() -> detach($cours);
        return redirect(route('listeDesAssociationsEnseignantsCours'));
    }
  
    // Liste des enseigants associes a un cours
    public function listeEnseignantsAssociationCours($cours_id){
        $cours = Cour::where('id',$cours_id)->get();
        $users = User::where('type','enseignant')->get();
        return view('listeDesAssociationsEnseignants',['cours'=>$cours,'users'=>$users]);
    }

    // ------------ //
    // Statistiques //
    // ------------ //

     // Liste des Etudiants avec pagination
    public function listeDesEtudiants(){
        $etudiants = Etudiant::paginate(3);
        return view('listeDesEtudiants',['etudiants'=>$etudiants]);
    }

    // Recherche des etudiants
    public function listeEtudiantRecherche(Request $request){
        if($request->nom == null && $request->prenom == null && $request->noet == null){
            $etudiants = Etudiant::paginate(3);
            return view('listeDesEtudiants',['etudiants'=>$etudiants]);
        } else {
            $etudiants = Etudiant::orwhere('nom',$request->nom)
            ->orWhere('prenom',$request->prenom)
            ->orWhere('noet',$request->noet)
            ->paginate(3);
            return view('listeDesEtudiants',['etudiants'=>$etudiants]); 
        }    
    }
    // Liste des cours
    public function listeCours(){
        $cours = Cour::all();
        return view('listeDesCours',['cours'=>$cours]);
    }
    // Liste des seances pour un cours avec pagination
    public function listeSeanceCours($cours_id){
        $seances = Seance::where('cours_id',$cours_id)->paginate(3);
        return view('listeDesSeancesCours',['seances'=>$seances]);
    }

    // ------------------- //
    // Liste des presences //
    // ------------------- //

    // Liste de presence detaillee par etudiant
    public function listePresenceDetail($etudiant_id){
        $etudiants = Etudiant::findOrFail($etudiant_id);
        return view('listeDesPresenceDetaille',['etudiants'=>$etudiants]);
    }

    public function detailEtudiant($etudiant_id,$cours_id){
        $etudiants = Etudiant::findOrFail($etudiant_id);
        $cours = Cour::findOrFail($cours_id);
        $date_auj = Carbon::now()->addHours(2)->format("Y-m-d H:i:s");
        $nombreSeancePresents = $etudiants->seances->where('cours_id',$cours_id)->where('date_debut', '<=',$date_auj)->count();
        $nombreSeanceAbsents = $cours->seances->where('cours_id',$cours_id)->where('date_debut','<=',$date_auj)->count();
        $nombreSeanceAbsents = $nombreSeanceAbsents - $nombreSeancePresents;
        return view('detailPresenceEtudiant',['etudiants'=>$etudiants,'cours'=>$cours,'date_auj'=>$date_auj,'nombreSeancePresents'=>$nombreSeancePresents,'nombreSeanceAbsents'=>$nombreSeanceAbsents]);
    }

    // Liste des presences des etudiants par seance
    public function listePresenceEtudiantsSeance($seance_id){
        $seances = Seance::findOrFail($seance_id);  
        return view('listeDesPresenceSeance',['seances'=>$seances]);
    }

    // Liste des presences des etudiants par cours
    public function listePresenceEtudiantsCours($cours_id){
        $cours = Cour::findorfail($cours_id);
        $stocktables = [];
        $presents = [];
        foreach ($cours->seances as $seance){
            foreach ($seance->etudiants as $etudiants){    
                array_push($stocktables,$etudiants->id);
            }

        }
        $stocktables = array_unique($stocktables);
        foreach($stocktables as $present){
            $present = Etudiant::findorfail($present);
            array_push($presents,$present);
        }; 
        return view('listeDesPresenceCours',['cours'=>$cours,'presents'=>$presents]);
    }
    
}
