<?php

namespace App\Http\Controllers;

use App\Models\Cour;
use App\Models\User;
use App\Models\Seance;
use App\Models\Etudiant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    // ------------------------ //
    // Gestion des Utilisateurs //
    // ------------------------ //

    // Liste des Utilisateurs
    public function listeUser(){
        $users = User::all();
        return view('listeDesUsers',['users'=>$users]);
    }

    // fonction de filtrage par type 
    public function listeUserTri(Request $request){
        $v = $request->validate(
                [
                    'type' => 'required|alpha_dash',
                ]
            );
        if($request->type == "enseignant"){
            $users = User::where('type',$request->type)->get();
            return view('listeDesUsers',['users'=>$users]);
        } else if ($request->type == "gestionnaire"){
            $users = User::where('type',$request->type)->get();
            return view('listeDesUsers',['users'=>$users]);
        }else if($request->type=="admin"){
            $users = User::where('type',$request->type)->get();
            return view('listeDesUsers',['users'=>$users]);
        }else if($request->type=="null"){
            $users = User::where('type',null)->get();
            return view('listeDesUsers',['users'=>$users]);
        }else{
            $users = User::all();
            return view('listeDesUsers',['users'=>$users]);
        }
    }

    // Recherche par nom/prenom/login
    public function listeUserRecherche(Request $request){
        if($request->nom == null && $request->prenom == null && $request->login == null){
            $users = User::all();
            return view('listeDesUsers',['users'=>$users]);
        } else {
            $users = User::orwhere('nom',$request->nom)
            ->OrWhere('prenom',$request->prenom)
            ->OrWhere('login',$request->login)
            ->get();
            return view('listeDesUsers',['users'=>$users]);
        }
    }
    
    // Acceptation d'un utilisateur qui a ete auto-cree 
    public function validation(Request $request,$id){
        if($request->has('Accepter')){
        $users = User::findOrFail($id);
            $v = $request->validate(
                [
                    'type' => 'required|alpha_dash',
                ]
            );
            $users->type = $v['type'];
            $users->touch();
            $users->save();
            return redirect(route('listeUser'));
        } else {
            $users = User::findOrFail($id);
            return redirect(route('suppUserForm',['id'=>$id]));
        }
    }   

    // Formulaire de creation d'un utilisateur
    public function createNewUserForm(){
        return view('newUser');
    }

    // creation d'un utilisateur
    public function createNewUser(Request $request){
           $v = $request->validate(
                [
                    'nom' => 'required|alpha_dash',
                    'prenom' => 'required|alpha_dash',
                    'login' => 'required|alpha_dash',
                    'type' => 'required|alpha_dash',
                    'mdp' => 'required|confirmed',
                ]
            );
            $users = new User();
            $users -> nom = $request -> nom;
            $users -> prenom = $request -> prenom;
            $users -> login = $request -> login;
            $users -> type = $request -> type;
            $users -> mdp = Hash::make($request->mdp);
            $users -> save();
            return redirect()->route('listeUser');
    }

    // Formulaire de modification d'un utilisateur
    public function modifUserForm($id){
        $users = User::findOrFail($id);
        return view('modifUsers',['users'=>$users]);
    }

    // Modification d'un utilisateur y compris le type
    public function modifUser(Request $request,$id){
        $users = User::findOrFail($id);
            if($request->has('Modifier')){
                $v = $request->validate(
                [
                    'nom' => 'required|alpha_dash',
                    'prenom' => 'required|alpha_dash',
                    'login' => 'required|alpha_dash',
                    'mdp'=>'required|confirmed',
                    'type' => 'required|alpha_dash',
                ]
            );
            $users->nom = $request -> nom;
            $users->prenom = $request -> prenom;
            $users->mdp = Hash::make($request->mdp);
            $users->login = $request -> login;
            $users->type = $request -> type;
            $users->save();
            $request->session()->flash('modif', 'Utilisateur modifie');
            return redirect(route('listeUser'));
        } else {
            $request->session()->flash('modiffail', 'Modification annulee' );
            return redirect(route('listeUser'));
        }
    }

    // Formulaire de suppression 
    public function suppUserForm($id){
        $users = User::findOrFail($id);
        return view('suppUsers',['users'=>$users]);
    }
    
    // Suppresion d'un utilisateur
    public function suppUser(Request $request,$id){
        if($request -> confirmation =="Oui"){
            $users = User::findOrFail($id);
            $users -> cours() -> detach();
            $users -> delete();
            return redirect()->route('listeUser');
        } else {
            return redirect()->route('listeUser');
        }
    }

    // ----------------- //
    // Gestion des cours //
    // ----------------- // 

    // Formulaire de creation d'un cours
    public function createCourForm(){
        return view('createCourForm');
    }

    // Creation d'un cours
    public function createCour(Request $request){
        if($request->has('Ajouter')){
        $v = $request->validate(
                [
                    'intitule' => 'required|string|max:255|unique:cours',
                ]
            );
            $cours = new Cour();
            $cours -> intitule = $request -> intitule;
            $cours -> save();
            $request->session()->flash('create', 'Cours créer');
            return redirect()->route('listeCours');
        } else {
            $request->session()->flash('createfail', 'Cours non créer');
            return redirect()->route('listeCours');
        }
    }

    // Liste des cours
    public function listeCours(){
        $cours = Cour::all();
        return view('listeDesCours',['cours'=>$cours]);
    }

    // Recherche par intitule
    public function listeIntituleRecherche(Request $request){
        if($request->intitule == null){
            $cours = Cour::all();
            $request->session()->flash('rechercheIntituleFail', 'Recherche non trouvée');
            return view('listeDesCours',['cours'=>$cours]);
        } else {
            $cours = Cour::where('intitule',$request->intitule)->get();
            return view('listeDesCours',['cours'=>$cours]); 
        }
    }

    // Formulaire de modification du cours 
    public function modifCoursForm($id){
        $cours = Cour::findOrFail($id);
        return view('modifCours',['cours'=>$cours]);
    }

    // Modification d'un cours
    public function modifCours(Request $request,$id){
        $cours = Cour::findOrFail($id);
        if($request->has('Modifier')){
          $v = $request->validate(
                [
                    'intitule' => 'required|alpha_dash',
                ]
            );
            $cours->intitule = $v['intitule'];
            $cours->touch();
            $cours->save();
            $request->session()->flash('modif', 'Cours modifie');
            return redirect(route('listeCours'));
        } else {
            $request->session()->flash('modiffail', 'Modification annulee' );
            return redirect(route('listeCours'));
        }
    }

    // Formulaire de suppression d'un cours
    public function suppCoursForm($id){ 
        $cours = Cour::findOrFail($id);
        return view('suppCours',['cours' => $cours]);
    }

    // Suppresion d'un cours
    public function suppCours(Request $request,$id){
        if($request -> confirmation =="Oui"){
            $cours = Cour::findOrFail($id);
            $cours -> etudiants() -> detach();
            $cours -> users() -> detach();
            $seances = Seance::all();
            foreach($cours->seances as $seance){
                $seance->etudiants()->detach();
                $seance->delete();
            }
            $cours -> delete();
            $request -> session() -> flash('supprime','Suppression effectué');
            return redirect()->route('listeCours');
        } else {
            $request -> session() -> flash('supprimeFail','Suppression non effectué');
            return redirect()->route('listeCours');
        }
    }
    
}
