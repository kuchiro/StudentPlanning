<?php

namespace App\Http\Controllers;

use App\Models\Cour;
use App\Models\User;
use App\Models\Seance;
use App\Models\Etudiant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EnseignantController extends Controller
{
    // --------------------------- //
    // La liste des cours associes //
    // --------------------------- //

    // Liste des cours associé à l'enseignant connecté
    public function listeEnseignantCours(){
        $uid = Auth::user()->id;
        $cours = Cour::all();
        $users = User::where('id',$uid)->get();
        return view('listeCoursEnseignantAssociate',['cours'=>$cours,'users'=>$users]);
    }

    // --------------------- //
    // Gestion des presences //
    // --------------------- //

    // Liste des inscrits dans un cours
    public function listeInscritCours($cours_id){
        $cours = Cour::where('id',$cours_id)->get();
        $etudiants = Etudiant::all();
        return view('listeDesInscrit',['cours'=>$cours,'etudiants'=>$etudiants]);
    }

    // Pointage d’un etudiant
    public function pointageEtudiantSeance($cours_id){
        $seances = Seance::where('cours_id',$cours_id)->get();
        return view('SeancePointage',['seances'=>$seances]);
    }

    // Associer l'etudiant avec le cours
    public function pointageEtudiantSeanceVrai($seance_id,$etudiant_id){
        $seances = Seance::findOrFail($seance_id);
        $etudiants = Etudiant::findOrFail($etudiant_id);
        $etudiants -> seances() -> attach($seances);
        return redirect(route('listeDesPresences'));
    }

    // Liste des présences
    public function listeDesPresences(){
        $seances = Seance::all();
        $etudiants = Etudiant::all();
        return view('listeDesPresences',['seances'=>$seances,'etudiants'=>$etudiants]);
    }

    // Panier qui conserve tout les pointages
    public function pointageEtudiantsMultipleSeance($cours_id,$etudiant_id){
        $uid = Auth::user() -> id;
        $panier = session() ->  get('panier');
        $etudiants = Etudiant::findOrFail($etudiant_id);
            $panier[$etudiant_id] = [ 
                "etudiant_nom" => $etudiants->nom,
                "etudiant_prenom" => $etudiants->prenom,
                "noet" => $etudiants-> noet,
                "etudiant_id" => $etudiants->id
            ];
        session()->put('panier',$panier);
        return view('panier_pointer',['cours_id'=>$cours_id,'etudiant_id'=>$etudiant_id]);
    }

    // Formulaire de confirmation des pointages
    public function ajoutPanierDansPointageConfirmation($cours_id){
        return view('panier_pointer_confirmation',['cours_id'=>$cours_id]);
    }

    // Fonction qui applique le pointage multiple et les met dans la table
    public function ajoutPanierDansPointage(Request $request,$cours_id){ 
            $panier = session() -> get('panier');
            $seances = Seance::where('cours_id',$cours_id)->first();
        foreach($panier as $p){
            $stock = $p["etudiant_id"];
            $etudiants = Etudiant::where('id',$stock)->get();
            $seances -> etudiants() -> attach($etudiants);
        }
        $request->session()->forget('panier');
        return redirect()->route('listeDesPresences');
    }

    // fonction de liste des présents/absents par séance choisie
    public function listePresentAbsentSeance($cours_id,$seance_id)
    {
        $test = Cour::find($cours_id);
        $cours = Cour::findOrFail($cours_id);
        
        $seances = Seance::findOrFail($seance_id);
        $absents = array();
        if($seances->etudiants->isnotempty()){
            foreach($cours->etudiants as $etudiant){
                foreach($seances->etudiants as $present){
                    if($present->id == $etudiant->id){
                        break;
                    }
                }
                if($present->id != $etudiant->id){
                    array_push($absents,$etudiant);
                    }
                }
            } else {
                $absents = $cours -> etudiants;
            }
        return view('listeDesPresentAbsentParSeance',['cours'=>$cours,'seances'=>$seances,'absents'=>$absents]);
    }   
    
    // ---------------------------- //
    // Totaux de présence par cours //
    // ---------------------------- //

    // fonction du totaux de présence par cours
    public function totalPresenceCours($cours_id){
        $cours = Cour::findorfail($cours_id);
        $seances_total = $cours->seances()->count();
        
        $totaux = 0;
        $seances = $cours->seances;
        foreach($seances as $seance){
            $totaux += $seance->etudiants->count();
        }
        return view('listeTotalPresenceCours',['totaux'=>$totaux,'cours'=>$cours,'seances'=>$seances,'seances_total'=>$seances_total]);
    }

}
