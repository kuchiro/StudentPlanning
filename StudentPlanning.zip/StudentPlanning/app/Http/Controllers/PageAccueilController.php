<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageAccueilController extends Controller
{
    public function pageAccueil(){
        return view('mainPage');
    }

    public function profil(){
        return view('profil');
    }
}
