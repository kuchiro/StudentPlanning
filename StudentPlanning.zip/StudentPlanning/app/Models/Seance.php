<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Seance extends Model
{
    use HasFactory;
    
    function cours(){
        return $this->belongsTo(Cour::class,'id');
    }

    function etudiants(){
        return $this->belongsToMany(Etudiant::class,'presences','seance_id','etudiant_id');
    }
    public $timestamps = false;

}
