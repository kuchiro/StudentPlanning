<?php $__env->startSection('title','Liste des Presences des étudiants par cours'); ?>

<?php $__env->startSection('contents'); ?>

<table class="table table-dark">
    <?php $__currentLoopData = $presents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $present): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr><td><?php echo e($present->nom); ?></td>
<td><?php echo e($present->prenom); ?></td>
<td><?php echo e($present->noet); ?></td></tr>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/listeDesPresenceCours.blade.php ENDPATH**/ ?>