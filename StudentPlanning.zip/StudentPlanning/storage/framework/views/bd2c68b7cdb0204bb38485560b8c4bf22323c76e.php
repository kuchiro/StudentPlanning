<?php $__env->startSection('title','Enregistrement'); ?>

<?php $__env->startSection('contents'); ?>

<div class="container">
    <form method="post">
        <h1>Créer votre compte</h1>
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Nom</label>
                <input type="text" class="form-control" name="nom" value="<?php echo e(old('nom')); ?>" placeholder="Nom">
            </div>

        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Prénom</label>
                <input type="text" class="form-control" name="prenom" value="<?php echo e(old('prenom')); ?>" placeholder="Prenom">
            </div>
                     
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Login</label>
                <input type="text" class="form-control" name="login" value="<?php echo e(old('login')); ?>" placeholder="login">
            </div>
                    
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom"> MDP </label>
                <input type="password" class="form-control" name="mdp" placeholder="Mdp">
            </div>
                     
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Confirmer votre MDP </label>
                <input type="password" class="form-control" name="mdp_confirmation" placeholder="Confirmation MDP">
            </div>

        <div><a href="<?php echo e(route('login')); ?>">Déjà enregistré ?</a>
        <button class="btn btn-primary" type="submit">Envoyer</button></div>
        <?php echo csrf_field(); ?>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/L2_INFORMATIQUE/Programmation_Web/ProjetPW/resources/views/register.blade.php ENDPATH**/ ?>