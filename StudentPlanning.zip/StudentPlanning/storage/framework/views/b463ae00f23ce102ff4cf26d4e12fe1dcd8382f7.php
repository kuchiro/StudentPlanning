<!doctype html>

<html lang="en">

<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link href="/css/style.css" rel="stylesheet"> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

    <title><?php echo $__env->yieldContent('title'); ?></title>

</head>

<body>
<?php $__env->startSection('menu'); ?>

<?php if(auth()->guard()->guest()): ?> 

<div class="container">
    <div class="row">
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Login</h5>
                    <p class="card-text">Veuillez-vous connecter pour accéder aux outils </p>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Log in </a>
                </div>
            </div>
        </div>

        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Enregistrement</h5>
                    <p class="card-text">S'enregister pour accéder aux sites </p>
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-primary">Sign in</a>
                </div>
            </div>
        </div>
    </div>

</div>
<?php endif; ?>

<?php if(auth()->guard()->check()): ?>
<nav class="navbar navbar-light bg-white" >
    <div class="dropdown">
        <button type="button" class="btn  dropdown-toggle" data-bs-toggle="dropdown">
            <p class="material-icons">menu</p>
        </button>

        <div class="dropdown-menu">
            <?php if(Auth::user()->type=="admin"): ?>
            <a class="dropdown-item" href="<?php echo e(route('listeUser')); ?>">Liste des Utilisateurs</a>
            <a class="dropdown-item" href="<?php echo e(route('createUserForm')); ?>">Créer un utilisateur</a>
            <a class="dropdown-item" href="<?php echo e(route('createCourForm')); ?>">Créer un cours</a>
            <a class="dropdown-item" href="<?php echo e(route('listeCours')); ?>">Liste des cours</a>
            <?php endif; ?>
            
            <?php if(Auth::user()->type=="gestionnaire" || Auth::user()->type=="admin"): ?>
            <a class="dropdown-item"href="<?php echo e(route('listeEtudiants')); ?>" >Listes des étudiants</a>
            <a class="dropdown-item"href="<?php echo e(route('ajoutEtudiantForm')); ?>" >Ajout étudiant</a>
            <a class="dropdown-item"href="<?php echo e(route('listeCoursGestio')); ?>" >Liste des cours du gestionnaire</a>
            <a class="dropdown-item"href="<?php echo e(route('listeDesAssociationsEtudiantCours')); ?>" >Liste des associations etudiant cours</a>
            <a class="dropdown-item"href="<?php echo e(route('listeDesAssociationsEnseignantsCours')); ?>" >Liste des associations enseignant cours</a>
            <a class="dropdown-item"href="<?php echo e(route('listeDesEnseignants')); ?>" >Liste des enseignants</a>
            <a class="dropdown-item"href="<?php echo e(route('listeDesSeances')); ?>" >Liste des séances</a>
            <?php endif; ?>

            <?php if(Auth::user()->type=="enseignant" || Auth::user()->type=="admin"): ?>
            <a class="dropdown-item" href="<?php echo e(route('listeEnseignantCours')); ?>">Liste des cours associés</a>
            <a class="dropdown-item" href="<?php echo e(route('listeDesPresences')); ?>">Liste des présences en cours</a>
            <?php endif; ?>

        </div>
    </div>
    
    <div class="inscription">
        <div class="dropdown">

        
        <button type="button" class="btn  dropdown-toggle" data-bs-toggle="dropdown">
            <?php echo e(Auth::user()->login); ?>

        </button>
        
        <button type="button" class="btn btn-link"><a href="<?php echo e(route('logout')); ?>">Se deconnecter</a></button>

        <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo e(route('profil')); ?>">Voir mon profil</a>
            <?php if(Auth::user()->type != NULL): ?>
            <a class="dropdown-item" href="<?php echo e(route('modifNomPrenomForm')); ?>">Modifier votre profil</a>
            <a class="dropdown-item" href="<?php echo e(route('updateform')); ?>">ChangementMDP</a>
            <?php endif; ?>
        </div>
    </div>
</div>

</nav>
<?php endif; ?>

<?php echo $__env->yieldContent('contents'); ?>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
crossorigin="anonymous"></script>
</body>

</html>
<?php /**PATH /Users/wu/L2_INFORMATIQUE/Programmation_Web/ProjetPW/resources/views/modele.blade.php ENDPATH**/ ?>