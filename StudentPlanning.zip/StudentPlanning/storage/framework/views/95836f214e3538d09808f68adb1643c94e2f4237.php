<?php $__env->startSection('title','Liste des Etudiants'); ?>

<?php $__env->startSection('contents'); ?>

<div>Chercher un etudiant par nom prenom noet ? </div>
 <form action="<?php echo e(route('listeEtudiantRecherche')); ?>">
        <input type="text" name="nom" placeholder="Nom">
        <input type="text" name="prenom" placeholder="Prenom">
        <input type="text" name="noet" placeholder="NumeroEtudiant">
        <input type="submit" value="Envoyer">
        <?php echo csrf_field(); ?>
    </form>

<table class="table table-dark">
  <td>NOM</td>
  <td>PRENOM</td>
  <td>NUMÉRO ÉTUDIANT</td>
  <td>Supprimer</td>
  <td>Associer</td>
  <td>Mettre à jour</td>
  <?php $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
<tr>
    <td><?php echo e($etudiant->nom); ?></td>
    <td><?php echo e($etudiant->prenom); ?></td>
    <td><?php echo e($etudiant->noet); ?></td>
    <td><a href="<?php echo e(route('suppEtudiantForm',['id'=>$etudiant->id])); ?>">Supprimer cet etudiant</a></td>
    <td><a href="<?php echo e(route('associateEtudiants',['id'=>$etudiant->id])); ?>">Associer cet étudiant</a></td>
    <td><a href="<?php echo e(route('miseAJourEtudiantForm',['id'=>$etudiant->id])); ?>">Mise à jour</a></td>
    <td><a href="<?php echo e(route('listePresenceDetail',['etudiant_id'=>$etudiant->id])); ?>">Liste des presences détaillés pour l'étudiant</a></td>
</tr>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($etudiants -> links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/L2_INFORMATIQUE/Programmation_Web/ProjetPW/resources/views/listeDesEtudiants.blade.php ENDPATH**/ ?>