<?php $__env->startSection('title','Liste des associations etudiant cours'); ?>

<?php $__env->startSection('contents'); ?>
<table class="table table-dark">
    <td>COURS_ID</td>
    <td>Intitule</td>
    <td>ETUDIANT_ID</td>
    <td>NOM</td>
    <td>PRENOM</td>
    <td>NUMERO ETUDIANT</td>
<?php $__currentLoopData = $cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $cour->etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($cour->id); ?></td>
<td><?php echo e($cour->intitule); ?></td>
<td><?php echo e($etudiant->id); ?></td>
<td><?php echo e($etudiant->nom); ?></td>
<td><?php echo e($etudiant->prenom); ?></td>
<td><?php echo e($etudiant->noet); ?></td>
<td><a href="<?php echo e(route('associationSupprimerEtudiant',['cours_id'=>$cour->id,'etudiants'=>$etudiant->id])); ?>">Supprimer l'association</a></td>
<td><a href="<?php echo e(route('dissocierEtudiantsMultipleCours',['cours_id'=>$cour->id,'etudiant_id'=>$etudiant->id])); ?>">Supprime Multiple</a></td>

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/listeDesAssociationsEtudiantCours.blade.php ENDPATH**/ ?>