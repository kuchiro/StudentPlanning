<?php $__env->startSection('title','Liste des Presences'); ?>

<?php $__env->startSection('contents'); ?>

<table class="table table-dark">
    <tr>
        <td>ETUDIANT ID</td>
        <td>SEANCE ID</td>
        <td>NOM</td>
        <td>PRENOM</td>
        <td>NOET</td>
        <td>Date debut</td>
        <td>Date fin</td>
        <td>Cours_id</td>

    </tr>
  <?php $__currentLoopData = $seances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $seance->etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($etudiant->id); ?></td>
        <td><?php echo e($seance->id); ?></td>
        <td><?php echo e($etudiant->nom); ?></td>
        <td><?php echo e($etudiant->prenom); ?></td>
        <td><?php echo e($etudiant->noet); ?></td>
        <td><?php echo e($seance->date_debut); ?></td>
        <td><?php echo e($seance->date_fin); ?></td>
        <td><?php echo e($seance->cours_id); ?></td>
    </tr>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/listeDesPresences.blade.php ENDPATH**/ ?>