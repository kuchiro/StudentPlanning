<?php $__env->startSection('title','Passage Commande Panier'); ?>

<?php $__env->startSection('contents'); ?>

<?php if(Auth::user()->type=="enseignant"): ?>
    <p>Voulez-vous pointer tout les élèves ? </p>
    <form action="<?php echo e(route('ajoutPanierDansPointage',['cours_id'=>$cours_id])); ?>" method="post">
        <input type="submit" value="Oui" name="confirmation">
        <input type="submit" value="Non" name="confirmation">
        <?php echo csrf_field(); ?>
    </form>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/panier_pointer_confirmation.blade.php ENDPATH**/ ?>