<?php $__env->startSection('title','Liste des Presences Absents par séance '); ?>

<?php $__env->startSection('contents'); ?>

<table class="table table-dark">
    <thead>Liste des Présence à ce cours</thead>
    <tr><td>NOM</td>
    <td>Prenom</td>
    <td>Numero etudiant</td></tr>
    <?php $__currentLoopData = $seances->etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($seance->nom); ?></td>
     <td><?php echo e($seance->prenom); ?></td>
      <td><?php echo e($seance->noet); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<table class="table table-dark">
    <thead>Liste des absents à ce cours</thead>
    <tr>
        <td>Nom</td>
        <td>Prenom</td>
        <td>Numero etudiant</td>
    </tr>
<?php $__currentLoopData = $absents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <td><?php echo e($absent->nom); ?></td>
     <td><?php echo e($absent->prenom); ?></td>
      <td><?php echo e($absent->noet); ?></td>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/listeDesPresentAbsentParSeance.blade.php ENDPATH**/ ?>