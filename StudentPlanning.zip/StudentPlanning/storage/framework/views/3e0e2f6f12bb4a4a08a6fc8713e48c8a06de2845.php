<?php $__env->startSection('title','Détail Etudiant'); ?>

<?php $__env->startSection('contents'); ?>

<table>
    <tr><td>Nombre de présence : <?php echo e($nombreSeancePresents); ?></td>
<td>Nombre d'absences : <?php echo e($nombreSeanceAbsents); ?></td></tr>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/detailPresenceEtudiant.blade.php ENDPATH**/ ?>