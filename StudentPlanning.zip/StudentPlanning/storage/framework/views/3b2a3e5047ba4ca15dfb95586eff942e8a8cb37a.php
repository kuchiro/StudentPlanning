<?php $__env->startSection('title','Liste des Presences Detaillé par étudiant'); ?>

<?php $__env->startSection('contents'); ?>

<table class="table table-dark">
 
<?php $__currentLoopData = $etudiants->cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td><?php echo e($cour->intitule); ?></td>
<td><a href="<?php echo e(route('detailEtudiant',['etudiant_id'=>$etudiants->id,'cours_id'=>$cour->id])); ?>">Détail</a></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/listeDesPresenceDetaille.blade.php ENDPATH**/ ?>