<?php $__env->startSection('title','Modification Utilisateur Par Administrateur'); ?>

<?php $__env->startSection('contents'); ?>

<div class="container">
    <h1>Modification de l'utilisteur <?php echo e($users->nom); ?> <?php echo e($users->prenom); ?> <?php echo e($users->type); ?></h1>
    <form method="post">
        <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Nom</label>
                         <input type="text" class="form-control" name="nom" value="<?php echo e($users->nom); ?>" >
                     </div>
        
                      <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Prenom</label>
                         <input type="text" class="form-control" value="<?php echo e($users->prenom); ?>" name="prenom" >
                     </div>
                     
                    <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Login</label>
                         <input type="text" class="form-control" name="login"  value="<?php echo e($users->login); ?>" >
                     </div>
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Nouveau MDP </label>
                         <input type="text" class="form-control" name="mdp" placeholder="MDP">
                     </div>
        
                      <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Nouveau MDP Confirmation</label>
                        <input type="text" class="form-control" name="mdp_confirmation" placeholder="MDP_Confirmation">
                     </div>
                     
                    <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Type</label>
                          <select name="type" id="type" class="form-control" >
                <option value="enseignant">enseignant</option>
                <option value="gestionnaire">gestionnaire</option>
                <option value="admin">admin</option>
            </select>
                     </div>
        
                     <button class="btn btn-primary" type="submit" name="Modifier">Modifier</button>
       <button class="btn btn-primary" type="submit"  name="Annuler">Annuler</button>
        <?php echo csrf_field(); ?>
    </form>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/modifUsers.blade.php ENDPATH**/ ?>