<?php $__env->startSection('title','Liste des Seances'); ?>

<?php $__env->startSection('contents'); ?>

<table class="table table-dark">
  <td>DATE_DEBUT</td>
  <td>DATE_FIN</td>
  <?php $__currentLoopData = $seances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
<tr>
    <td><?php echo e($seance->date_debut); ?></td>
    <td><?php echo e($seance->date_fin); ?></td>
    <td><a href="<?php echo e(route('miseAJourSeanceForm',['id'=>$seance->id])); ?>">Mettre à jour</a></td>
    <td><a href="<?php echo e(route('suppSeanceForm',['id'=>$seance->id])); ?>">Supprimer</a></td>
    <td><a href="<?php echo e(route('listePresenceEtudiantsSeance',['seance_id'=>$seance->id])); ?>">Liste des présences des étudiants par séance</a></td>
</tr>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/listeDesSeances.blade.php ENDPATH**/ ?>