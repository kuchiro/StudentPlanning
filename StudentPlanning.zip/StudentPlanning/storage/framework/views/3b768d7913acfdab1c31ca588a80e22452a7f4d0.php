<?php $__env->startSection('title','Modifier un Cours'); ?>

<?php $__env->startSection('contents'); ?>

<div class="container" >
    <form method="post">
        <div class="col-12">Nouveau Intitule</div>
        <div class="col-12"><input type="text" name="intitule" value="<?php echo e(old('intitule')); ?>" placeholder="Intitule"></div>
       <input type="submit" name="Modifier" value="Modifier">
       <input type="submit" name="Annuler" value="Annuler">
        <?php echo csrf_field(); ?>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/L2_INFORMATIQUE/Programmation_Web/ProjetPW/resources/views/modifCours.blade.php ENDPATH**/ ?>