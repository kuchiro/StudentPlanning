<?php $__env->startSection('title','Mise A Jour Etudiants'); ?>

<?php $__env->startSection('contents'); ?>

<div class="container" >
    <form method="post">
        <div class="col-12">Nom </div>
        <div class="col-12"><input type="text" name="nom" value="<?php echo e(old('nom')); ?>" placeholder="nom"></div>
        <div class="col-12">Prenom </div>
        <div class="col-12"><input type="text" name="prenom" placeholder="prenom"></div>
        <div class="col-12">Numero Etudiants </div>
        <div class="col-12"><input type="text" name="noet" placeholder="NumeroEtudiants"></div>
        <input type="submit" value="Envoyer">
        <?php echo csrf_field(); ?>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/miseAJourForm.blade.php ENDPATH**/ ?>