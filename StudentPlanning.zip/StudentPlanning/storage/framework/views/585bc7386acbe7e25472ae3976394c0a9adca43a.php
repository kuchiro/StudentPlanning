<?php $__env->startSection('title','Mise A Jour Etudiants'); ?>

<?php $__env->startSection('contents'); ?>

<div class="container" >
    <h1>Mise à jour de l'étudiant <?php echo e($etudiants->nom); ?> <?php echo e($etudiants->prenom); ?> <?php echo e($etudiants->noet); ?></h1>
    <form method="post">

        <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Nom</label>
                         <input type="text" class="form-control" name="nom" value="<?php echo e(old('nom')); ?>" placeholder="nom">
                     </div>
        
                      <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom"> Prenom </label>
                         <input type="text" class="form-control" name="prenom" placeholder="prenom">
                     </div>
                     
                    <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Numéro étudiants </label>
                         <input type="text" class="form-control" name="noet" placeholder="NumeroEtudiants">
                     </div>

                     <button class="btn btn-primary" type="submit">Envoyer</button>
        <?php echo csrf_field(); ?>
    </form>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/miseAJourEtudiantForm.blade.php ENDPATH**/ ?>