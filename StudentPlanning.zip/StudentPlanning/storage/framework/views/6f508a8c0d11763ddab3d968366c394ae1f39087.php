<?php $__env->startSection('title','Liste des Enseignants'); ?>

<?php $__env->startSection('contents'); ?>

<table class="table table-dark">
  <td>Nom</td>
  <td>Prenom</td>
  <td>Login</td>
  <td>Type</td>
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
<tr><td><?php echo e($user->nom); ?></td>
    <td><?php echo e($user->prenom); ?></td>
    <td><?php echo e($user->login); ?></td>
    <td><?php echo e($user->type); ?></td>
    <td><a href="<?php echo e(route('associationEnseignant',['id'=>$user->id])); ?>">Associer cet enseignant</a></td>
<td>
</tr>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/listeDesEnseignants.blade.php ENDPATH**/ ?>