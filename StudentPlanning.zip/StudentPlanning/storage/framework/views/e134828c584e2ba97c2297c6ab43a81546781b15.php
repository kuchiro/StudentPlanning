<?php $__env->startSection('title','Panier'); ?>

<?php $__env->startSection('contents'); ?>

<?php if(Auth::user()->type=="enseignant" || Auth::user()->type=="admin" ): ?>
    <a href="<?php echo e(route('listeInscritCours',['cours_id'=>$cours_id])); ?>">Ajouter un autre étudiant à pointer ? </a>
<?php endif; ?>

<?php if(Auth::user()->type=="gestionnaire" || Auth::user()->type=="admin" ): ?>
    <a href="<?php echo e(route('listeEtudiantPourMultiple',['cours_id'=>$cours_id])); ?>">Ajouter un autre étudiant à associer ? </a>
<?php endif; ?>

<p>Votre Panier :</p>
    <?php if(session ('panier') ): ?>

        <?php $__currentLoopData = session('panier'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
<div class="container">
    <table class="table">
      <thead class="thead-dark">
            <tr><td>ID</td>
                <td>Nom</td>
                <td>Prenom</td>
                <td>Numero Etudiant</td>
            </tr>
        </thead>

    <tbody>
        <td><?php echo e($etudiant['etudiant_id']); ?></td>
        <td><?php echo e($etudiant['etudiant_nom']); ?></td>
        <td><?php echo e($etudiant['etudiant_prenom']); ?></td>
        <td><?php echo e($etudiant['noet']); ?></td>
</tbody>
</table>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php if(Auth::user()->type=="enseignant" || Auth::user()->type=="admin" ): ?>
<button><a href="<?php echo e(route('ajoutPanierDansPointageConfirmation',['cours_id'=>$cours_id])); ?>">Valider le pointage Multiple</a></button>
<?php endif; ?>

<?php if(Auth::user()->type=="gestionnaire" || Auth::user()->type=="admin" ): ?>
<button><a href="<?php echo e(route('ajoutPanierDansAssocierConfirmation',['cours_id'=>$cours_id])); ?>">Valider l'association Multiple</a></button>
<?php endif; ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/panier.blade.php ENDPATH**/ ?>