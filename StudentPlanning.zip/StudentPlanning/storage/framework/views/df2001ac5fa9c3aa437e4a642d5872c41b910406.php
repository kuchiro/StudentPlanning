<?php $__env->startSection('title','Liste des Etudiants'); ?>

<?php $__env->startSection('contents'); ?>

<table class="table table-dark">
  <td>ID</td>
  <td>NOM</td>
  <td>PRENOM</td>
  <td>NUMÉRO ÉTUDIANT</td>
  <?php $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
<tr><td><?php echo e($etudiant->id); ?></td>
    <td><?php echo e($etudiant->nom); ?></td>
    <td><?php echo e($etudiant->prenom); ?></td>
    <td><?php echo e($etudiant->noet); ?></td>
    <td><a href="<?php echo e(route('associerEtudiantsMultipleCours',['cours_id'=>$cours_id,'etudiant_id'=>$etudiant->id])); ?>">Associer Multiple</a></td>
<td>
</tr>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/listeEtudiantMultiple.blade.php ENDPATH**/ ?>