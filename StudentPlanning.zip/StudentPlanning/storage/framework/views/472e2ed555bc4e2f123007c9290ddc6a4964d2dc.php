<?php $__env->startSection('title','Modification Nom Ou Prenom'); ?>

<?php $__env->startSection('contents'); ?>

<div class="container" >
    <h1>Modification du nom ou prénom </h1>
    <form method="post">
        <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Nom</label>
                         <input type="text" class="form-control" name="nom" value="<?php echo e(Auth::user()->nom); ?>" placeholder="Nom">
                     </div>
        <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Prénom</label>
                         <input type="text" class="form-control" name="prenom" value="<?php echo e(Auth::user()->prenom); ?>" placeholder="Prenom">
                     </div>
                     <button class="btn btn-primary" type="submit">Envoyer</button>
       
        <?php echo csrf_field(); ?>
    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/modificationNomPrenomForm.blade.php ENDPATH**/ ?>