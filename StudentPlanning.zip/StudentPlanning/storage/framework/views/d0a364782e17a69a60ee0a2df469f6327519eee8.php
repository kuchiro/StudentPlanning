<?php $__env->startSection('title','Nouveau Etudiant'); ?>

<?php $__env->startSection('contents'); ?>


<div class="container">
    <h1>Ajouter un étudiant</h1>
   <form method="post" action="<?php echo e(route('ajoutEtudiant')); ?>">
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Nom</label>
                <input type="text" class="form-control" name="nom" placeholder="Richard" value="<?php echo e(old('nom')); ?>">
            </div>
        
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Prenom </label>
                <input type="text" class="form-control" name="prenom" placeholder="Albert" value="<?php echo e(old('prenom')); ?>">    
            </div>
                     
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Numéro étudiant</label>
                <input type="text" class="form-control" name="noet" placeholder="12345678" value="<?php echo e(old('noet')); ?>">
            </div>
            <button class="btn btn-primary" type="submit">Envoyer</button>
        <?php echo csrf_field(); ?>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/ajoutEtudiantForm.blade.php ENDPATH**/ ?>