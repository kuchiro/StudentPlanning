<?php $__env->startSection('title','Modification du Mot De Passe'); ?>

<?php $__env->startSection('contents'); ?>

<div class="container">
    <h1>Changement de mot de passe</h1>
        <form method="post">
            <div class="form-row">
                <div class="col-md-4 mb-3">
                    <label for="prenom">Login</label>
                    <input type="text" class ="form-control" value="<?php echo e(Auth::user()->login); ?>" name="login" placeholder="Login">
                </div>
                
            <div class="form-row">
                <div class="col-md-4 mb-3">
                    <label for="prenom"> MDP </label>
                    <input type="password" class="form-control" name="mdp" placeholder="Mdp">
                </div>
                     
            <div class="form-row">
                <div class="col-md-4 mb-3">
                    <label for="prenom">Nouveau MDP </label>
                    <input type="password" class="form-control" name="mdp_confirmation" placeholder="NouveauMdp">
                </div>
                
            <button class="btn btn-primary" type="submit">Envoyer</button>
        <?php echo csrf_field(); ?>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/L2_INFORMATIQUE/Programmation_Web/ProjetPW/resources/views/updateform.blade.php ENDPATH**/ ?>