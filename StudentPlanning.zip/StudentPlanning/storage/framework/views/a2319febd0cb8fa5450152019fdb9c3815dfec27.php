<?php $__env->startSection('title','Liste des Utilisateurs'); ?>

<?php $__env->startSection('contents'); ?>

<?php if(session()->has('enseignant')): ?>
<p class="enseignant"><?php echo e(session()->get('enseignant')); ?></p>
<?php endif; ?>
<?php if(session()->has('gestionnaire')): ?>
<p class="gestionnaire"><?php echo e(session()->get('gestionnaire')); ?></p>
<?php endif; ?>
<?php if(session()->has('admin')): ?>
<p class="admin"><?php echo e(session()->get('admin')); ?></p>
<?php endif; ?>
<?php if(session()->has('null')): ?>
<p class="null"><?php echo e(session()->get('null')); ?></p>
<?php endif; ?>

<div class="container">
  <div>
    <p>Quel type d'utilisateur voulez-vous voir ? </p>
    <form action="<?php echo e(route('listeUserTri')); ?>" method="get">
            <select name="type" id="type" placeholder="Type">
                <option value="enseignant">enseignant</option>
                <option value="gestionnaire">gestionnaire</option>
                <option value="admin">admin</option>
                <option value="null">Utilisateurs inactives</option>
                <option value="all">Tout les utilisateurs</option>
            </select>
            <input type="submit" value="Envoyer">
            <?php echo csrf_field(); ?>
    </form>
  </div>
<div>

<p>Quel personne rechercher-vous ?</p>
<form action="<?php echo e(route('listeUserRecherche')); ?>">
        <input type="text" name="nom" placeholder="Nom">
        <input type="text" name="prenom" placeholder="Prenom">
        <input type="text" name="login" placeholder="Login">
        <input type="submit" value="Envoyer">
        <?php echo csrf_field(); ?>
    </form>
</div>


<table class="table table-stripped ">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Nom</th>
      <th scope="col">Prenom</th>
      <th scope="col">Login</th>
      <th scope="col">Type</th>
      <th scope="col">Modification de l'utilisateur</th>
      <th scope="col">Suppression de l'utilisateur</th>
    </tr>
  </thead>
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
  <tr><td><?php echo e($user->nom); ?></td>
    <td><?php echo e($user->prenom); ?></td>
    <td><?php echo e($user->login); ?></td>
    <td><?php echo e($user->type); ?>

    <?php if($user->type == NULL): ?>
    <form action="<?php echo e(route('validation',['id' => $user->id])); ?>" method="post">
            <select name="type" id="type" >
                <option value="enseignant">enseignant</option>
                <option value="gestionnaire">gestionnaire</option>
                <option value="admin">admin</option>
            </select>
            <div><input type="submit" value="Accepter" name="Accepter">
            <input type="submit" value="Refuser" name="Refuser"></div>
            <?php echo csrf_field(); ?>
            </form>
    <?php endif; ?>
    <td><a href="<?php echo e(route('modifUserForm',['id'=>$user->id])); ?>">Modifier</a></td>
    <td><a href="<?php echo e(route('suppUserForm',['id'=>$user->id])); ?>">Supprimer</a></td>
</tr>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/L2_INFORMATIQUE/Programmation_Web/ProjetPW/resources/views/listeDesUsers.blade.php ENDPATH**/ ?>