<?php $__env->startSection('title','Liste des Cours'); ?>

<?php $__env->startSection('contents'); ?>

<?php if(session()->has('create')): ?>
<p class="create"><?php echo e(session()->get('create')); ?></p>
<?php endif; ?>
<?php if(session()->has('createfail')): ?>
<p class="createfail"><?php echo e(session()->get('createfail')); ?></p>
<?php endif; ?>
<?php if(session()->has('modif')): ?>
<p class="modif"><?php echo e(session()->get('modif')); ?></p>
<?php endif; ?>
<?php if(session()->has('modiffail')): ?>
<p class="modiffail"><?php echo e(session()->get('modiffail')); ?></p>
<?php endif; ?>
<?php if(session()->has('rechercheIntituleFail')): ?>
<p class="rechercheIntituleFail"><?php echo e(session()->get('rechercheIntituleFail')); ?></p>
<?php endif; ?>
<?php if(session()->has('supprime')): ?>
<p class="supprime"><?php echo e(session()->get('supprime')); ?></p>
<?php endif; ?>
<?php if(session()->has('supprimeFail')): ?>
<p class="supprimeFail"><?php echo e(session()->get('supprimeFail')); ?></p>
<?php endif; ?>

<?php if(Auth::user()->type=="admin"): ?>
<div>Chercher un cours par l'intitulé ? </div>
 <form action="<?php echo e(route('listeIntituleRecherche')); ?>">
        <input type="text" name="intitule" placeholder="Intitule">
        <input type="submit" value="Envoyer">
        <?php echo csrf_field(); ?>
    </form>
</br>
<?php endif; ?>
<table class="table table-dark">
  <td>INTITULE</td>
  <td colspan=10></td>
  <?php $__currentLoopData = $cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
<tr>
    <td><?php echo e($cour->intitule); ?></td>
    <?php if(Auth::user()->type=="admin"): ?>
    <td><a href="<?php echo e(route('modifCoursForm',['id'=>$cour->id])); ?>">Modifier</a></td>
    <td><a href="<?php echo e(route('suppCoursForm',['id'=>$cour->id])); ?>">Supprimer</a></td>
    <?php endif; ?>
    
    <td><a href="<?php echo e(route('createNewSeanceForm',['id' => $cour->id])); ?>">Ajouter une séance de cours </a></td>
    <td><a href="<?php echo e(route('listeSeanceCours',['cours_id'=>$cour->id])); ?>">Liste des séances pour un cours</a></td>
    <td><a href="<?php echo e(route('listeEnseignantsAssociationCours',['cours_id'=>$cour->id])); ?>">Liste des enseignants à ce cours</a></td>
    <td><a href="<?php echo e(route('listeEtudiantAssociationCeCours',['cours_id'=>$cour->id])); ?>">Liste des étudiants à ce cours</a></td>
    <td><a href="<?php echo e(route('listePresenceEtudiantsCours',['cours_id'=>$cour->id])); ?>">Liste des présences des étudiants par cours</a></td>
    <td><a href="<?php echo e(route('copieCours',['cours_id'=>$cour->id])); ?>">Cours à copier</a></td>
    <td><a href="<?php echo e(route('listeEtudiantPourMultiple',['cours_id'=>$cour->id])); ?>">Associer des Etudiants multiple</a></td>

    

    <?php if(Auth::user()->type=="enseignant" || Auth::user()->type=="admin"): ?>
    <td><a href="<?php echo e(route('listeInscritCours',['cours_id'=>$cour->id])); ?>">Liste des inscrits à ce cours</a></td>
    <?php endif; ?>
    
</tr>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/listeDesCours.blade.php ENDPATH**/ ?>