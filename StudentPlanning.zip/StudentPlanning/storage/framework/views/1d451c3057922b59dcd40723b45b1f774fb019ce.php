<?php $__env->startSection('title','Profil'); ?>

<?php $__env->startSection('contents'); ?>

<div class="container" >
  <div>Votre nom : <?php echo e(Auth::user()->nom); ?></div>
  <div>Votre prenom : <?php echo e(Auth::user()->prenom); ?></div>
  <div>Votre login : <?php echo e(Auth::user()->login); ?></div>
  <div>Votre type : <?php echo e(Auth::user()->type); ?>

    <?php if(Auth::user()->type == NULL): ?>
      Utilisateur inactives
     <?php endif; ?>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/L2_INFORMATIQUE/Programmation_Web/ProjetPW/resources/views/profil.blade.php ENDPATH**/ ?>