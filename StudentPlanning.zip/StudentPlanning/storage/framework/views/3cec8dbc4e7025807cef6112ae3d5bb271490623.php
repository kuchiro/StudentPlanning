<?php $__env->startSection('title','Login'); ?>

<?php $__env->startSection('contents'); ?>

<div class="container" >
  <form method="post">
    <h1>Connectez-vous</h1>
        <div class="form-row">
          <div class="col-md-4 mb-3">
            <label for="prenom">Login</label>
                <input type="text" class ="form-control" name="login" placeholder="Login">
                     </div>
                    <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom"> MDP </label>
                         <input type="password" class="form-control" name="mdp" placeholder="Mot de passe">
                     </div>
     
           <a href="<?php echo e(route('register')); ?>">Pas de compte ?</a>

        <button class="btn btn-primary" type="submit">Connexion</button>
      <?php echo csrf_field(); ?>
</form>
</div>
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/login.blade.php ENDPATH**/ ?>