<?php $__env->startSection('title','Supprimer une seance'); ?>

<?php $__env->startSection('contents'); ?>
<div class="container">
    <h1>Voulez-vous supprimer la séance du <?php echo e($seances->date_debut); ?></h1>

                     <form action="<?php echo e(route('suppSeanceCours',['id'=>$seances->id])); ?>" method="post">
                         <div class="form-row">
                             <div class="col-md-4 mb-3">
        <input type="submit" value="Oui" name="confirmation">
        <input type="submit" value="Non" name="confirmation">
</div>
        
            
</div>
        <?php echo csrf_field(); ?>
    </form>
</div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/suppSeance.blade.php ENDPATH**/ ?>