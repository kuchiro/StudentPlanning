<?php $__env->startSection('title','Liste des Cours copies vers une autre association'); ?>

<?php $__env->startSection('contents'); ?>

 <?php $__currentLoopData = $cours_copie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cours_cop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <td>Le cours copier est : <?php echo e($cours_cop->intitule); ?></td>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<table class="table table-dark">
<tr>
  <td>ID</td>
  <td>INTITULE</td>
  <td>created_at</td>
  <td>updated_at</td>
</tr>
 

  <?php $__currentLoopData = $cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
<tr><td><?php echo e($cour->id); ?></td>
    <td><?php echo e($cour->intitule); ?></td>
    <td><?php echo e($cour->created_at); ?></td>
    <td><?php echo e($cour->updated_at); ?></td>
    <?php $__currentLoopData = $cours_copie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cours_cop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <td><a href="<?php echo e(route('copieAssociationsCoursACours',['cours_id'=>$cours_cop->id,'cours_id1'=>$cour->id])); ?>">Associer avec</a></td>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/listeDesCoursACopier.blade.php ENDPATH**/ ?>