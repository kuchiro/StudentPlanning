<?php $__env->startSection('title','connecter'); ?>

<?php $__env->startSection('contents'); ?>
  <p>C BON</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/connecter.blade.php ENDPATH**/ ?>