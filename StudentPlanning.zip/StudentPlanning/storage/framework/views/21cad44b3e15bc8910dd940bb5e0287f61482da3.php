<?php $__env->startSection('title','Nouveau Utilisateur'); ?>

<?php $__env->startSection('contents'); ?>

<div class="container">
<h1>Ajouter un nouveau Utilisateur</h1>
     

        <form method="post" action="<?php echo e(route('createUser')); ?>">
        <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Nom</label>
                         <input type="text" class="form-control" name="nom" placeholder="Nom" value="<?php echo e(old('nom')); ?>">
                     </div>
        
                      <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Prenom</label>
                         <input type="text" class="form-control" name="prenom" placeholder="Prenom" value="<?php echo e(old('prenom')); ?>">
                     </div>
                     
                    <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Login</label>
                         <input type="text" class="form-control" name="login" placeholder="Login" >
                     </div>
                     <div class="col-md-4 mb-3">
                         <label for="prenom">MDP </label>
                          <input type="password" class="form-control" name="mdp" placeholder="Mdp" >
                     </div>
        
                      <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Nouveau MDP Confirmation</label>
                        <input type="password" class="form-control" name="mdp_confirmation" placeholder="Confirmation MDP">
                     </div>
                     
                    <div class="form-row">
                     <div class="col-md-4 mb-3">
                         <label for="prenom">Type</label>
                          <select name="type" id="type" class="form-control" >
                <option value="enseignant">enseignant</option>
                <option value="gestionnaire">gestionnaire</option>
                <option value="admin">admin</option>
            </select>
                     </div>
        
                     <button class="btn btn-primary" type="submit" name="Modifier">Envoyer</button>
        <?php echo csrf_field(); ?>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/newUser.blade.php ENDPATH**/ ?>