<?php $__env->startSection('title','Validation Inscription'); ?>

<?php $__env->startSection('contents'); ?>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(route('validation',['id' => $user->id])); ?>">
   <select name="statut" id="statut" >
                <option value="enseignant">enseignant</option>
                <option value="gestionnaire">gestionnaire</option>
                <option value="admin">admin</option>
            </select>
        <input type="submit" value="Envoyer">
        <?php echo csrf_field(); ?>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/validationFormulaire.blade.php ENDPATH**/ ?>