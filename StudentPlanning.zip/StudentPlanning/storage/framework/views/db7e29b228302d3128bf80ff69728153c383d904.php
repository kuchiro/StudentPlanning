<?php $__env->startSection('title','Passage Commande Panier'); ?>

<?php $__env->startSection('contents'); ?>

<?php if(Auth::user()->type=="gestionnaire"): ?>
<p>Voulez-vous dissocier tout les élèves ? </p>
    <form action="<?php echo e(route('ajoutPanierDansDissocier',['cours_id'=>$cours_id])); ?>" method="post">
        <input type="submit" value="Oui" name="confirmation">
        <input type="submit" value="Non" name="confirmation">
        <?php echo csrf_field(); ?>
    </form>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/panier_confirmation_suppression.blade.php ENDPATH**/ ?>