<?php $__env->startSection('title','Page Principale'); ?>

<?php $__env->startSection('contents'); ?>

<h1>Bienvenue sur le site pour gérer votre scolarité </h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/L2_INFORMATIQUE/Programmation_Web/ProjetPW/resources/views/mainPage.blade.php ENDPATH**/ ?>