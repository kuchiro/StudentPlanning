<?php $__env->startSection('title','Seance Pointage'); ?>

<?php $__env->startSection('contents'); ?>
   
<table class="table table-dark">
    <tr>
        <td>Date_debut</td>
        <td>Date_fin</td>
    </tr>
    <?php $__currentLoopData = $seances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($seance->date_debut); ?></td>
        <td><?php echo e($seance->date_fin); ?></td>
        <td><a href="<?php echo e(route('listeInscritCours',['cours_id'=>$seance->cours_id])); ?>">Liste des inscrits dans cette séance</a></td>
        <td><a href="<?php echo e(route('listePresentAbsentSeance',['cours_id'=>$seance->cours_id,'seance_id'=>$seance->id])); ?>">Liste des présents/absents de cette séance</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/SeancePointage.blade.php ENDPATH**/ ?>