<?php $__env->startSection('title','Formulaire de validation Utilisateur'); ?>

<?php $__env->startSection('contents'); ?>
<form action="<?php echo e(route('validation',['id' => $users->id])); ?>" method="post">
            <select name="type" id="type" >
                <option value="enseignant">enseignant</option>
                <option value="gestionnaire">gestionnaire</option>
                <option value="admin">admin</option>
            </select>
            <td><input type="submit" value="Accepter" name="Accepter"></td>
            <td><input type="submit" value="Refuser" name="Refuser"></td>
            <?php echo csrf_field(); ?>
            </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/validationForm.blade.php ENDPATH**/ ?>