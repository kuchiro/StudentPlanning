<?php $__env->startSection('title','Nouvelle Seance de cours '); ?>

<?php $__env->startSection('contents'); ?>

<p>Voulez-vous ajouter une Seance ? </p> 

<?php $__currentLoopData = $cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="post" action="<?php echo e(route('createNewSeanceCour',['id' => $cour->id])); ?>">
        <input type="datetime-local" step="1" name="date_debut" placeholder="date_debut" value="<?php echo e(old('date_debut')); ?>">
        <input type="datetime-local" step="1" name="date_fin" placeholder="date_fin" value="<?php echo e(old('date_fin')); ?>">
        <input type="submit" value="Envoyer"> 
        <?php echo csrf_field(); ?>
        </form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/createNewSeanceForm.blade.php ENDPATH**/ ?>