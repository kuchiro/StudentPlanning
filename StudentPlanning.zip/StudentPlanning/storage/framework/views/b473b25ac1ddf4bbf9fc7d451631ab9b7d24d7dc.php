<?php $__env->startSection('title','Supprimer un etudiant'); ?>

<?php $__env->startSection('contents'); ?>
    <p>Voulez-vous supprimer <?php echo e($etudiants->nom); ?> ?</p>
    <form action="<?php echo e(route('suppEtudiant',['id'=>$etudiants->id])); ?>" method="post">
        <input type="submit" value="Oui" name="confirmation">
        <input type="submit" value="Non" name="confirmation">
        <?php echo csrf_field(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/suppEtudiant.blade.php ENDPATH**/ ?>