<?php $__env->startSection('title','Nouveau Cour'); ?>

<?php $__env->startSection('contents'); ?>

<div class="container">
<p>Voulez-vous ajouter un Cours ? </p> 

<form method="post" action="<?php echo e(route('createCour')); ?>">
        <input type="text" name="intitule" placeholder="Intitule" value="<?php echo e(old('intitule')); ?>">
        <input type="submit" name="Ajouter" value="Ajouter"> 
        <input type="submit" name="Annuler" value="Annuler">
        <?php echo csrf_field(); ?>
        </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/createCourForm.blade.php ENDPATH**/ ?>