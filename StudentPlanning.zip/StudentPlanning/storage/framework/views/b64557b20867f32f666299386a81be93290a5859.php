<?php $__env->startSection('title','Supprimer un Cours'); ?>

<?php $__env->startSection('contents'); ?>
    <p>Voulez-vous supprimer ?</p>
    <form action="<?php echo e(route('associationSupprimer',['cours_id'=>$cours_etudiant->cours_id,'etudiants'=>$cours_etudiant->etudiant_id])); ?>" method="post">
        <input type="submit" value="Oui" name="confirmation">
        <input type="submit" value="Non" name="confirmation">
        <?php echo csrf_field(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/suppAssociationConfirmation.blade.php ENDPATH**/ ?>