<?php $__env->startSection('title','Rechercher un cours'); ?>

<?php $__env->startSection('contents'); ?>
     <form action="<?php echo e(route('listeIntituleRecherche')); ?>" method="post">
        <input type="text" name="intitule" placeholder="Intitule">
        <input type="submit" value="Envoyer">
        <?php echo csrf_field(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wu/ProjetPW/resources/views/rechercheIntitule.blade.php ENDPATH**/ ?>