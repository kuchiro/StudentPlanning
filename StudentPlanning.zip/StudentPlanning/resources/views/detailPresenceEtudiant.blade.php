@extends('modele')

@section('title','Détail Etudiant')

@section('contents')

<table>
    <tr><td>Nombre de présence : {{$nombreSeancePresents}}</td>
<td>Nombre d'absences : {{$nombreSeanceAbsents}}</td></tr>
</table>

@endsection