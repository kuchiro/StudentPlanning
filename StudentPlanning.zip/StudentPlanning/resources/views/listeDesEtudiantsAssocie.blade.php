@extends('modele')

@section('title','Liste des associations etudiant cours')

@section('contents')

<table class="table table-dark">
    <td>Intitule</td>
    <td>NOM</td>
    <td>PRENOM</td>
    <td>NUMERO ETUDIANT</td>
    @foreach($cours as $cour)
        @foreach($cour->etudiants as $etudiant)
            <tr><td>{{$cour->intitule}}</td>
                <td>{{$etudiant->nom}}</td>
                <td>{{$etudiant->prenom}}</td>
                <td>{{$etudiant->noet}}</td>
            </tr>
        @endforeach
    @endforeach

</table>

@endsection