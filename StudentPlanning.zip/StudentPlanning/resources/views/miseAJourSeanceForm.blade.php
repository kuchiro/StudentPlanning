@extends('modele')

@section('title','Mise A Jour Seance')

@section('contents')

<div class="container" >
    <form method="post">
        <h1>Mise a jour de la seance</h1>
        <h1> du {{$seances->date_debut}}</h1>
        <h1> à {{$seances->date_fin}}</h1>
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">date_debut</label>
                <input type="datetime-local" step="1" class="form-control" name="date_debut" placeholder="Date_Debut">
            </div>
        
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom"> date_fin </label>
                <input type="datetime-local" step="1" class="form-control" name="date_fin" placeholder="Date_Fin">
            </div>
            <button class="btn btn-primary" type="submit">Envoyer</button>
        @csrf
    </form>
</div>
@endsection