@extends('modele')

@section('title','Liste des Cours associe Utilisateur connecte ')

@section('contents')

<table class="table table-dark">
  <p>Bonjour monsieur {{Auth::user()->nom}} {{Auth::user()->prenom}}</p>
  
  @foreach($users as $user)
  @foreach($user->cours as $cour)
  <tr>
  <td>{{$cour->intitule}}</td>
   <td><a href="{{route('listeInscritCours',['cours_id'=>$cour->id])}}">Liste des inscrits à ce cours</a></td>
   <td><a href="{{route('pointageEtudiantSeance',['cours_id'=>$cour->id])}}">Pointage pour cette séance</a></td>
   <td><a href="{{route('totalPresenceCours',['cours_id'=>$cour->id])}}">Totaux de présence</a></td>
</tr>
  @endforeach
  @endforeach
</table>

@endsection
