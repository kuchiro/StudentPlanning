@extends('modele')

@section('title','Page Principale')

@section('contents')

<h1>Bienvenue sur le site pour gérer votre scolarité </h1>

@endsection