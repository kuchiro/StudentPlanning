@extends('modele')

@section('title','Passage Commande Panier')

@section('contents')

@if(Auth::user()->type=="enseignant")
    <p>Voulez-vous pointer tout les élèves ? </p>
    <form action="{{route('ajoutPanierDansPointage',['cours_id'=>$cours_id])}}" method="post">
        <input type="submit" value="Oui" name="confirmation">
        <input type="submit" value="Non" name="confirmation">
        @csrf
    </form>
@endif

@endsection
