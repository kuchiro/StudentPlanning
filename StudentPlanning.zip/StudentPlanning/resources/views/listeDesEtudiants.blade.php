@extends('modele')

@section('title','Liste des Etudiants')

@section('contents')

<div>Chercher un etudiant par nom prenom noet ? </div>
 <form action="{{route('listeEtudiantRecherche')}}">
        <input type="text" name="nom" placeholder="Nom">
        <input type="text" name="prenom" placeholder="Prenom">
        <input type="text" name="noet" placeholder="NumeroEtudiant">
        <input type="submit" value="Envoyer">
        @csrf
    </form>

<table class="table table-dark">
  <td>NOM</td>
  <td>PRENOM</td>
  <td>NUMÉRO ÉTUDIANT</td>
  <td>Supprimer</td>
  <td>Associer</td>
  <td>Mettre à jour</td>
  @foreach($etudiants as $etudiant)
        
<tr>
    <td>{{$etudiant->nom}}</td>
    <td>{{$etudiant->prenom}}</td>
    <td>{{$etudiant->noet}}</td>
    <td><a href="{{route('suppEtudiantForm',['id'=>$etudiant->id])}}">Supprimer cet etudiant</a></td>
    <td><a href="{{route('associateEtudiants',['id'=>$etudiant->id])}}">Associer cet étudiant</a></td>
    <td><a href="{{route('miseAJourEtudiantForm',['id'=>$etudiant->id])}}">Mise à jour</a></td>
    <td><a href="{{route('listePresenceDetail',['etudiant_id'=>$etudiant->id])}}">Liste des presences détaillés pour l'étudiant</a></td>
</tr>

  @endforeach
</table>
{{$etudiants -> links()}}

@endsection
