@extends('modele')

@section('title','Liste des Presences Absents par séance ')

@section('contents')

<table class="table table-dark">
    <thead>Liste des Présence à ce cours</thead>
    <tr><td>NOM</td>
    <td>Prenom</td>
    <td>Numero etudiant</td></tr>
    @foreach($seances->etudiants as $seance)
    <tr>
    <td>{{$seance->nom}}</td>
     <td>{{$seance->prenom}}</td>
      <td>{{$seance->noet}}</td>
    </tr>
    @endforeach
</table>

<table class="table table-dark">
    <thead>Liste des absents à ce cours</thead>
    <tr>
        <td>Nom</td>
        <td>Prenom</td>
        <td>Numero etudiant</td>
    </tr>
@foreach($absents as $absent)
    <td>{{$absent->nom}}</td>
     <td>{{$absent->prenom}}</td>
      <td>{{$absent->noet}}</td>
    @endforeach

</table>
  

@endsection
