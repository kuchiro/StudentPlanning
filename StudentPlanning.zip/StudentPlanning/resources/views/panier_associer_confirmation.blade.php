@extends('modele')

@section('title','Confirmation association multiple')

@section('contents')

@if(Auth::user()->type=="gestionnaire"|| Auth::user()->type=="admin" )
<p>Voulez-vous associer tout les élèves ? </p>
    <form action="{{route('ajoutPanierDansAssocier',['cours_id'=>$cours_id])}}" method="post">
        <input type="submit" value="Oui" name="confirmation">
        <input type="submit" value="Non" name="confirmation">
        @csrf
    </form>
@endif
@endsection
