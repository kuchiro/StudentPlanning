@extends('modele')

@section('title','Liste des Inscrits dans un cours')

@section('contents')

<table class="table table-dark">
  <td>Intitule</td>
  <td>Nom</td>
  <td>Prenom</td>
  <td>Numero etudiant</td>
  <td>Présence</td>
  @foreach($cours as $cour)
    @foreach($cour->etudiants as $etudiant)
      <tr><td>{{$cour->intitule}}</td>
          <td>{{$etudiant->nom}}</td>
          <td>{{$etudiant->prenom}}</td>
          <td>{{$etudiant->noet}}</td> 
          <td><a href="{{route('pointageEtudiantSeanceVrai',['etudiant_id'=>$etudiant->id,'seance_id'=>$cour->id])}}">Pointage</a></td>
          <td><a href="{{route('pointageEtudiantsMultipleSeance',['etudiant_id'=>$etudiant->id,'cours_id'=>$cour->id])}}">Pointage Multiple</a></td>
      </tr>
    @endforeach
  @endforeach
</table>

@endsection
