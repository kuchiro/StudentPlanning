@extends('modele')

@section('title','Nouveau Cour')

@section('contents')

<div class="container">
<p>Voulez-vous ajouter un Cours ? </p> 

<form method="post" action="{{route('createCour')}}">
        <input type="text" name="intitule" placeholder="Intitule" value="{{old('intitule')}}">
        <input type="submit" name="Ajouter" value="Ajouter"> 
        <input type="submit" name="Annuler" value="Annuler">
        @csrf
        </form>

</div>
@endsection