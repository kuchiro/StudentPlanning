@extends('modele')

@section('title','Modification Nom Ou Prenom')

@section('contents')

<div class="container" >
    <h1>Modification du nom ou prénom </h1>
    <form method="post">
        <div class="form-row">
                     <div class="col-md-4 mb-3">
                            <label for="prenom">Nom</label>
                            <input type="text" class="form-control" name="nom" value="{{Auth::user()->nom}}" placeholder="Nom">
                     </div>

        <div class="form-row">
                     <div class="col-md-4 mb-3">
                            <label for="prenom">Prénom</label>
                            <input type="text" class="form-control" name="prenom" value="{{Auth::user()->prenom}}" placeholder="Prenom">
                     </div>
                <button class="btn btn-primary" type="submit">Envoyer</button>
        @csrf
    </form>
</div>

@endsection