@extends('modele')

@section('title','Liste des Presences des étudiants par cours')

@section('contents')

<table class="table table-dark">
    @foreach($presents as $present)
    <tr><td>{{$present->nom}}</td>
        <td>{{$present->prenom}}</td>
        <td>{{$present->noet}}</td></tr>
        
    @endforeach
</table>

@endsection
