@extends('modele')

@section('title','Liste des Cours pour association enseignant')

@section('contents')


<table class="table table-dark">
  <td>INTITULE</td>
  <td>Listes des enseignants associé au cours </td>
  @foreach($cours as $cour)
        
<tr>
    <td>{{$cour->intitule}}</td>
    <td><a href="{{route('associationEnseignantsCours',['id2'=>$cour->id,'id'=>$users->id])}}">Associer avec l'enseignant</a></td>
</tr>

  @endforeach
</table>

@endsection
