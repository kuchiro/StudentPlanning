@extends('modele')

@section('title','Liste des Cours pour association etudiant')

@section('contents')


<table class="table table-dark">
  <td>INTITULE</td>
  <td>Listes des étudiants associé au cours </td>
  @foreach($cours as $cour)
        
<tr>
    <td>{{$cour->intitule}}</td>
    <td><a href="{{route('associateEtudiantsCours',['id2'=>$cour->id,'id'=>$etudiants->id])}}">Associer avec l'étudiant</a></td>
</tr>

  @endforeach
</table>

@endsection
