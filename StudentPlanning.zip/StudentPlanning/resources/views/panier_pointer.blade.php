@extends('modele')

@section('title','Panier pointer multiple')

@section('contents')

@if(Auth::user()->type=="enseignant" || Auth::user()->type=="admin" )
    <a href="{{route('listeInscritCours',['cours_id'=>$cours_id])}}">Ajouter un autre étudiant à pointer ? </a>
@endif

<p>Votre Panier :</p>
    @if(session ('panier') )

        @foreach( session('panier') as $etudiant )
        
<div class="container">
    <table class="table">
        <thead class="thead-dark">
            <tr><td>Nom</td>
                <td>Prenom</td>
                <td>Numero Etudiant</td>
            </tr>
        </thead>

        <tbody>
            <tr><td>{{$etudiant['etudiant_nom']}}</td>
            <td>{{$etudiant['etudiant_prenom']}}</td>
            <td>{{$etudiant['noet']}}</td></tr>
        </tbody>
    </table>
</div>
@endforeach

@if(Auth::user()->type=="enseignant" || Auth::user()->type=="admin" )
<button><a href="{{route('ajoutPanierDansPointageConfirmation',['cours_id'=>$cours_id])}}">Valider le pointage Multiple</a></button>
@endif

@endif

@endsection
