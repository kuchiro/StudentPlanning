@extends('modele')

@section('title','Liste des Presences')

@section('contents')

<table class="table table-dark">
    <tr>
        <td>NOM</td>
        <td>PRENOM</td>
        <td>NOET</td>
        <td>Date debut</td>
        <td>Date fin</td>
      </tr>

  @foreach($seances as $seance)
    @foreach($seance->etudiants as $etudiant)

    <tr>
        <td>{{$etudiant->nom}}</td>
        <td>{{$etudiant->prenom}}</td>
        <td>{{$etudiant->noet}}</td>
        <td>{{$seance->date_debut}}</td>
        <td>{{$seance->date_fin}}</td>
    </tr>
    
    @endforeach
  @endforeach
  
</table>

@endsection
