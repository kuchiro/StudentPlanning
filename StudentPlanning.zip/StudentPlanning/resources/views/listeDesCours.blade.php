@extends('modele')

@section('title','Liste des Cours')

@section('contents')

@if(session()->has('create'))
<p class="create">{{session()->get('create')}}</p>
@endif
@if(session()->has('createfail'))
<p class="createfail">{{session()->get('createfail')}}</p>
@endif
@if(session()->has('modif'))
<p class="modif">{{session()->get('modif')}}</p>
@endif
@if(session()->has('modiffail'))
<p class="modiffail">{{session()->get('modiffail')}}</p>
@endif
@if(session()->has('rechercheIntituleFail'))
<p class="rechercheIntituleFail">{{session()->get('rechercheIntituleFail')}}</p>
@endif
@if(session()->has('supprime'))
<p class="supprime">{{session()->get('supprime')}}</p>
@endif
@if(session()->has('supprimeFail'))
<p class="supprimeFail">{{session()->get('supprimeFail')}}</p>
@endif

@if(Auth::user()->type=="admin")
<div>Chercher un cours par l'intitulé ? </div>
 <form action="{{route('listeIntituleRecherche')}}">
        <input type="text" name="intitule" placeholder="Intitule">
        <input type="submit" value="Envoyer">
        @csrf
    </form>
</br>
@endif
<table class="table table-dark">
  <td>INTITULE</td>
  <td colspan=10></td>
  @foreach($cours as $cour)
        
<tr>
    <td>{{$cour->intitule}}</td>
    @if(Auth::user()->type=="admin")
    <td><a href="{{route('modifCoursForm',['id'=>$cour->id])}}">Modifier</a></td>
    <td><a href="{{route('suppCoursForm',['id'=>$cour->id])}}">Supprimer</a></td>
    @endif
    
    <td><a href="{{route('createNewSeanceForm',['id' => $cour->id])}}">Ajouter une séance de cours </a></td>
    <td><a href="{{route('listeSeanceCours',['cours_id'=>$cour->id])}}">Liste des séances pour un cours</a></td>
    <td><a href="{{route('listeEnseignantsAssociationCours',['cours_id'=>$cour->id])}}">Liste des enseignants à ce cours</a></td>
    <td><a href="{{route('listeEtudiantAssociationCeCours',['cours_id'=>$cour->id])}}">Liste des étudiants à ce cours</a></td>
    <td><a href="{{route('listePresenceEtudiantsCours',['cours_id'=>$cour->id])}}">Liste des présences des étudiants par cours</a></td>
    <td><a href="{{route('copieCours',['cours_id'=>$cour->id])}}">Cours à copier</a></td>
    <td><a href="{{route('listeEtudiantPourMultiple',['cours_id'=>$cour->id])}}">Associer des Etudiants multiple</a></td>

    

    @if(Auth::user()->type=="enseignant" || Auth::user()->type=="admin")
    <td><a href="{{route('listeInscritCours',['cours_id'=>$cour->id])}}">Liste des inscrits à ce cours</a></td>
    @endif
    
</tr>

  @endforeach
</table>

@endsection
