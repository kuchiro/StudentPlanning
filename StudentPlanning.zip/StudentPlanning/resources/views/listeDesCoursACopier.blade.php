@extends('modele')

@section('title','Liste des Cours copies vers une autre association')

@section('contents')

 @foreach($cours_copie as $cours_cop)
  <td>Le cours copier est : {{$cours_cop->intitule}}</td>
  @endforeach

<table class="table table-dark">
<tr>
  <td>ID</td>
  <td>INTITULE</td>
  <td>created_at</td>
  <td>updated_at</td>
</tr>
 
  @foreach($cours as $cour)
        
<tr><td>{{$cour->id}}</td>
    <td>{{$cour->intitule}}</td>
    <td>{{$cour->created_at}}</td>
    <td>{{$cour->updated_at}}</td>
    @foreach($cours_copie as $cours_cop)
    <td><a href="{{route('copieAssociationsCoursACours',['cours_id'=>$cours_cop->id,'cours_id1'=>$cour->id])}}">Associer avec</a></td>
    @endforeach
</tr>

  @endforeach
</table>

@endsection
