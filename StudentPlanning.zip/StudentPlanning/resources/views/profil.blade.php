@extends('modele')

@section('title','Profil')

@section('contents')

<div class="container" >
  <div>Votre nom : {{Auth::user()->nom}}</div>
  <div>Votre prenom : {{Auth::user()->prenom}}</div>
  <div>Votre login : {{Auth::user()->login}}</div>
  <div>Votre type : {{Auth::user()->type}}
    @if(Auth::user()->type == NULL)
      Utilisateur inactives
     @endif
   </div>
</div>

@endsection