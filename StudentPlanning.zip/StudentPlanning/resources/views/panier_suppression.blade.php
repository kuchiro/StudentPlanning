@extends('modele')

@section('title','Panier dissocier multiple')

@section('contents')

@if(Auth::user()->type=="gestionnaire" || Auth::user()->type=="admin")
    <a href="{{route('listeDesAssociationsEtudiantCours')}}">Ajouter un autre étudiant à dissocier ? </a>
@endif

<p>Votre Panier :</p>
    @if(session ('panier') )

        @foreach( session('panier') as $etudiant )
        
        <div class="container">
            <table class="table">
                <thead class="thead-dark">
                    <tr><td>Nom</td>
                        <td>Prenom</td>
                        <td>Numero Etudiant</td>
                    </tr>
                </thead>
                
                <tbody>
                    <tr>
                    <td>{{$etudiant['etudiant_nom']}}</td>
                    <td>{{$etudiant['etudiant_prenom']}}</td>
                    <td>{{$etudiant['noet']}}</td></tr>
                </tbody>
            </table>
        @endforeach

        </div>

@if(Auth::user()->type=="gestionnaire" || Auth::user()->type=="admin" )
<button><a href="{{route('ajoutPanierDansDissocierConfirmation',['cours_id'=>$cours_id])}}">Valider la suppression multiple</a></button>
@endif

@endif

@endsection
