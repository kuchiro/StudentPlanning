@extends('modele')

@section('title','Liste des Utilisateurs')

@section('contents')

@if(session()->has('enseignant'))
<p class="enseignant">{{session()->get('enseignant')}}</p>
@endif
@if(session()->has('gestionnaire'))
<p class="gestionnaire">{{session()->get('gestionnaire')}}</p>
@endif
@if(session()->has('admin'))
<p class="admin">{{session()->get('admin')}}</p>
@endif
@if(session()->has('null'))
<p class="null">{{session()->get('null')}}</p>
@endif

<div class="container">
  <div>
    <p>Quel type d'utilisateur voulez-vous voir ? </p>
    <form action="{{route('listeUserTri')}}" method="get">
            <select name="type" id="type" placeholder="Type">
                <option value="enseignant">enseignant</option>
                <option value="gestionnaire">gestionnaire</option>
                <option value="admin">admin</option>
                <option value="null">Utilisateurs inactives</option>
                <option value="all">Tout les utilisateurs</option>
            </select>
            <input type="submit" value="Envoyer">
            @csrf
    </form>
  </div>
<div>

<p>Quel personne rechercher-vous ?</p>
<form action="{{route('listeUserRecherche')}}">
        <input type="text" name="nom" placeholder="Nom">
        <input type="text" name="prenom" placeholder="Prenom">
        <input type="text" name="login" placeholder="Login">
        <input type="submit" value="Envoyer">
        @csrf
    </form>
</div>


<table class="table table-stripped ">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Nom</th>
      <th scope="col">Prenom</th>
      <th scope="col">Login</th>
      <th scope="col">Type</th>
      <th scope="col">Modification de l'utilisateur</th>
      <th scope="col">Suppression de l'utilisateur</th>
    </tr>
  </thead>
  @foreach($users as $user)
        
  <tr><td>{{$user->nom}}</td>
    <td>{{$user->prenom}}</td>
    <td>{{$user->login}}</td>
    <td>{{$user->type}}
    @if($user->type == NULL)
    <form action="{{route('validation',['id' => $user->id])}}" method="post">
            <select name="type" id="type" >
                <option value="enseignant">enseignant</option>
                <option value="gestionnaire">gestionnaire</option>
                <option value="admin">admin</option>
            </select>
            <div><input type="submit" value="Accepter" name="Accepter">
            <input type="submit" value="Refuser" name="Refuser"></div>
            @csrf
            </form>
    @endif
    <td><a href="{{route('modifUserForm',['id'=>$user->id])}}">Modifier</a></td>
    <td><a href="{{route('suppUserForm',['id'=>$user->id])}}">Supprimer</a></td>
</tr>

  @endforeach
</table>
</div>
@endsection
