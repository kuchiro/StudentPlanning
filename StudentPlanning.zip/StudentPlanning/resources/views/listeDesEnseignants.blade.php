@extends('modele')

@section('title','Liste des Enseignants')

@section('contents')

<table class="table table-dark">
  <td>Nom</td>
  <td>Prenom</td>
  <td>Login</td>
  <td>Type</td>
  @foreach($users as $user)
        
<tr><td>{{$user->nom}}</td>
    <td>{{$user->prenom}}</td>
    <td>{{$user->login}}</td>
    <td>{{$user->type}}</td>
    <td><a href="{{route('associationEnseignant',['id'=>$user->id])}}">Associer cet enseignant</a></td>
<td>
</tr>

  @endforeach
</table>
@endsection
