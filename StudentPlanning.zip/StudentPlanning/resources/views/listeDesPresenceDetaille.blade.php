@extends('modele')

@section('title','Liste des Presences Detaillé par étudiant')

@section('contents')

<table class="table table-dark">
    @foreach($etudiants->cours as $cour)
        <tr><td>{{$cour->intitule}}</td>
        <td><a href="{{route('detailEtudiant',['etudiant_id'=>$etudiants->id,'cours_id'=>$cour->id])}}">Détail</a></td></tr>
    @endforeach
</table>

@endsection
