@extends('modele')

@section('title','Nouvelle Seance de cours ')

@section('contents')

<p>Voulez-vous ajouter une Seance ? </p> 

@foreach($cours as $cour)
<form method="post" action="{{route('createNewSeanceCour',['id' => $cour->id])}}">
        <input type="datetime-local" step="1" name="date_debut" placeholder="date_debut" value="{{old('date_debut')}}">
        <input type="datetime-local" step="1" name="date_fin" placeholder="date_fin" value="{{old('date_fin')}}">
        <input type="submit" value="Envoyer"> 
        @csrf
        </form>
@endforeach

@endsection