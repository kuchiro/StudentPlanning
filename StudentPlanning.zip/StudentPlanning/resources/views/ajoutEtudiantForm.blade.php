@extends('modele')

@section('title','Nouveau Etudiant')

@section('contents')


<div class="container">
    <h1>Ajouter un étudiant</h1>
   <form method="post" action="{{route('ajoutEtudiant')}}">
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Nom</label>
                <input type="text" class="form-control" name="nom" placeholder="Richard" value="{{old('nom')}}">
            </div>
        
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Prenom </label>
                <input type="text" class="form-control" name="prenom" placeholder="Albert" value="{{old('prenom')}}">    
            </div>
                     
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Numéro étudiant</label>
                <input type="text" class="form-control" name="noet" placeholder="12345678" value="{{old('noet')}}">
            </div>
            <button class="btn btn-primary" type="submit">Envoyer</button>
        @csrf
    </form>
</div>

@endsection