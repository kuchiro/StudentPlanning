@extends('modele')

@section('title','Liste des associations etudiant cours')

@section('contents')
<table class="table table-dark">
    <td>Intitule</td>
    <td>NOM</td>
    <td>PRENOM</td>
    <td>NUMERO ETUDIANT</td>
@foreach($cours as $cour)
@foreach($cour->etudiants as $etudiant)
<tr>
<td>{{$cour->intitule}}</td>
<td>{{$etudiant->nom}}</td>
<td>{{$etudiant->prenom}}</td>
<td>{{$etudiant->noet}}</td>
<td><a href="{{route('associationSupprimerEtudiant',['cours_id'=>$cour->id,'etudiants'=>$etudiant->id])}}">Supprimer l'association</a></td>
<td><a href="{{route('dissocierEtudiantsMultipleCours',['cours_id'=>$cour->id,'etudiant_id'=>$etudiant->id])}}">Supprime Multiple</a></td>

</tr>

@endforeach
@endforeach


</table>



@endsection