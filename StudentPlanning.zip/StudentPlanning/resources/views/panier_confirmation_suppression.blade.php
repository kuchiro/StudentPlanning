@extends('modele')

@section('title','Confirmation des dissociations)

@section('contents')

@if(Auth::user()->type=="gestionnaire")
<p>Voulez-vous dissocier tout les élèves ? </p>
    <form action="{{route('ajoutPanierDansDissocier',['cours_id'=>$cours_id])}}" method="post">
        <input type="submit" value="Oui" name="confirmation">
        <input type="submit" value="Non" name="confirmation">
        @csrf
    </form>
@endif
@endsection
