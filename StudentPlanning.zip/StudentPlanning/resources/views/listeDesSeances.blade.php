@extends('modele')

@section('title','Liste des Seances')

@section('contents')

<table class="table table-dark">
  <td>DATE_DEBUT</td>
  <td>DATE_FIN</td>
  @foreach($seances as $seance)
        
<tr>
    <td>{{$seance->date_debut}}</td>
    <td>{{$seance->date_fin}}</td>
    <td><a href="{{route('miseAJourSeanceForm',['id'=>$seance->id])}}">Mettre à jour</a></td>
    <td><a href="{{route('suppSeanceForm',['id'=>$seance->id])}}">Supprimer</a></td>
    <td><a href="{{route('listePresenceEtudiantsSeance',['seance_id'=>$seance->id])}}">Liste des présences des étudiants par séance</a></td>
</tr>

  @endforeach
</table>

@endsection
