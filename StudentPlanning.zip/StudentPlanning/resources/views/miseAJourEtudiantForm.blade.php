@extends('modele')

@section('title','Mise A Jour Etudiants')

@section('contents')

<div class="container" >
    <h1>Mise à jour de l'étudiant {{$etudiants->nom}} {{$etudiants->prenom}} {{$etudiants->noet}}</h1>
    <form method="post">
        <div class="form-row">
            <div class="col-md-4 mb-3">
                    <label for="prenom">Nom</label>
                    <input type="text" class="form-control" name="nom" value="{{old('nom')}}" placeholder="nom">
            </div>
        
        <div class="form-row">
            <div class="col-md-4 mb-3">
                    <label for="prenom"> Prenom </label>
                    <input type="text" class="form-control" name="prenom" placeholder="prenom">
            </div>
                     
        <div class="form-row">
            <div class="col-md-4 mb-3">
                    <label for="prenom">Numéro étudiants </label>
                    <input type="text" class="form-control" name="noet" placeholder="NumeroEtudiants">
            </div>
            <button class="btn btn-primary" type="submit">Envoyer</button>
        @csrf
    </form>

</div>

@endsection