@extends('modele')

@section('title','Modification du Mot De Passe')

@section('contents')

<div class="container">
    <h1>Changement de mot de passe</h1>
        <form method="post">
            <div class="form-row">
                <div class="col-md-4 mb-3">
                    <label for="prenom">Login</label>
                    <input type="text" class ="form-control" value="{{Auth::user()->login}}" name="login" placeholder="Login">
                </div>
                
            <div class="form-row">
                <div class="col-md-4 mb-3">
                    <label for="prenom"> MDP </label>
                    <input type="password" class="form-control" name="mdp" placeholder="Mdp">
                </div>
                     
            <div class="form-row">
                <div class="col-md-4 mb-3">
                    <label for="prenom">Nouveau MDP </label>
                    <input type="password" class="form-control" name="mdp_confirmation" placeholder="NouveauMdp">
                </div>
                
            <button class="btn btn-primary" type="submit">Envoyer</button>
        @csrf
    </form>
</div>
@endsection