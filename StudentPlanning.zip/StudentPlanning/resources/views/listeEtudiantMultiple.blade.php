@extends('modele')

@section('title',"Liste des Etudiants pour l'association multiple")

@section('contents')

<table class="table table-dark">
  <td>NOM</td>
  <td>PRENOM</td>
  <td>NUMÉRO ÉTUDIANT</td>
  @foreach($etudiants as $etudiant)
        
  <tr><td>{{$etudiant->nom}}</td>
    <td>{{$etudiant->prenom}}</td>
    <td>{{$etudiant->noet}}</td>
    <td><a href="{{route('associerEtudiantsMultipleCours',['cours_id'=>$cours_id,'etudiant_id'=>$etudiant->id])}}">Associer Multiple</a></td>
  </tr>

  @endforeach
</table>

@endsection
