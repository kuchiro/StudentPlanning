@extends('modele')

@section('title','Supprimer une seance')

@section('contents')

<div class="container">
    <h1>Voulez-vous supprimer la séance du {{$seances->date_debut}}</h1>
    <form action="{{route('suppSeanceCours',['id'=>$seances->id])}}" method="post">
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <input type="submit" value="Oui" name="confirmation">
                <input type="submit" value="Non" name="confirmation">
            </div>
        </div>
        @csrf
    </form>
</div>
    
@endsection
