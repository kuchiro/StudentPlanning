@extends('modele')

@section('title','Modifier un Cours')

@section('contents')

<div class="container" >
    <form method="post">
        <div class="col-12">Nouveau Intitule</div>
        <div class="col-12"><input type="text" name="intitule" value="{{old('intitule')}}" placeholder="Intitule"></div>
       <input type="submit" name="Modifier" value="Modifier">
       <input type="submit" name="Annuler" value="Annuler">
        @csrf
    </form>

</div>
@endsection