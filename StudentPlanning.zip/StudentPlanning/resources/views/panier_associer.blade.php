@extends('modele')

@section('title','Panier associer')

@section('contents')

@if(Auth::user()->type=="gestionnaire" || Auth::user()->type=="admin" )
    <a href="{{route('listeEtudiantPourMultiple',['cours_id'=>$cours_id])}}">Ajouter un autre étudiant à associer ? </a>
@endif

<p>Votre Panier :</p>
    @if(session ('panier') )

        @foreach( session('panier') as $etudiant )
        
    <table class="table">
      <thead class="thead-dark">
            <tr><td>Nom</td>
                <td>Prenom</td>
                <td>Numero Etudiant</td>
            </tr>
        </thead>

        <tbody>
        <tr><td>{{$etudiant['etudiant_nom']}}</td>
        <td>{{$etudiant['etudiant_prenom']}}</td>
        <td>{{$etudiant['noet']}}</td></tr>
        </tbody>
    </table>
@endforeach

@if(Auth::user()->type=="gestionnaire" || Auth::user()->type=="admin" )
<button><a href="{{route('ajoutPanierDansAssocierConfirmation',['cours_id'=>$cours_id])}}">Valider l'association Multiple</a></button>
@endif

@endif

@endsection
