@extends('modele')

@section('title','Liste des Presences des étudiants par séance')

@section('contents')

<table class="table table-dark">
    Pour la séance du {{$seances->date_debut}}
    @foreach($seances->etudiants as $etudiant)
      <tr><td>{{$etudiant->nom}}</td>
          <td>{{$etudiant->prenom}}</td>
        <td>{{$etudiant->noet}}</td></tr>
    @endforeach
</table>

@endsection
