@extends('modele')

@section('title','Seance Pointage')

@section('contents')
   
<table class="table table-dark">
    <tr>
        <td>Date_debut</td>
        <td>Date_fin</td>
    </tr>
    @foreach($seances as $seance)
    <tr>
        <td>{{$seance->date_debut}}</td>
        <td>{{$seance->date_fin}}</td>
        <td><a href="{{route('listeInscritCours',['cours_id'=>$seance->cours_id])}}">Liste des inscrits dans cette séance</a></td>
        <td><a href="{{route('listePresentAbsentSeance',['cours_id'=>$seance->cours_id,'seance_id'=>$seance->id])}}">Liste des présents/absents de cette séance</a></td>
    </tr>
    @endforeach
   </table>
@endsection
