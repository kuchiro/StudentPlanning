@extends('modele')

@section('title','Liste des associations enseignant cours')

@section('contents')
<table class="table table-dark">
    <td>Intitule</td>
    <td>Nom</td>
    <td>Prenom</td>
    @foreach($cours as $cour)
    @foreach($cour->users as $user)
    <tr>
    <td>{{$cour->intitule}}</td>
    <td>{{$user->nom}}</td>
    <td>{{$user->prenom}}</td>
    <td><a href="{{route('associationSupprimerEnseignant',['cours_id'=>$cour->id,'users'=>$user->id])}}">Supprimer l'association</a></td>
    </tr>
    @endforeach
    @endforeach
</table>

@endsection