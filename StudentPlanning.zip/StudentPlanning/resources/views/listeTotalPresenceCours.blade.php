@extends('modele')

@section('title','Liste des Presences Total')

@section('contents')

<table class="table table-dark">
    @foreach($cours->etudiants as $etudiant)
    <tr><td>{{$etudiant->nom}}</td>
        <td>{{$etudiant->prenom}}</td>
        <td>{{$etudiant->noet}}</td>
@php
$total_presence = 0
@endphp

    @foreach($etudiant->seances as $seance)

        @if($seance->cours_id == $cours->id)

        @php 
            $total_presence++
        @endphp

        @endif

    @endforeach

<td>{{$total_presence}}/{{$seances_total}}</td>

</tr>
    @endforeach
</table>


@endsection
