@extends('modele')

@section('title','Liste des Seances pour un cours')

@section('contents')

<table class="table table-dark">
  <td>COURS_ID</td>
  <td>DATE_DEBUT</td>
  <td>DATE_FIN</td>
  @foreach($seances as $seance)
       <tr>
           <td>{{$seance->cours_id}}</td>
           <td>{{$seance->date_debut}}</td>
           <td>{{$seance->date_fin}}</td>
       </tr> 
  @endforeach
</table>

{{$seances->links()}}

@endsection
