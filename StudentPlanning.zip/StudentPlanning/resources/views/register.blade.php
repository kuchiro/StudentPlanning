@extends('modele')

@section('title','Enregistrement')

@section('contents')

<div class="container">
    <form method="post">
        <h1>Créer votre compte</h1>
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Nom</label>
                <input type="text" class="form-control" name="nom" value="{{old('nom')}}" placeholder="Nom">
            </div>

        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Prénom</label>
                <input type="text" class="form-control" name="prenom" value="{{old('prenom')}}" placeholder="Prenom">
            </div>
                     
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Login</label>
                <input type="text" class="form-control" name="login" value="{{old('login')}}" placeholder="login">
            </div>
                    
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom"> MDP </label>
                <input type="password" class="form-control" name="mdp" placeholder="Mdp">
            </div>
                     
        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label for="prenom">Confirmer votre MDP </label>
                <input type="password" class="form-control" name="mdp_confirmation" placeholder="Confirmation MDP">
            </div>

        <div><a href="{{route('login')}}">Déjà enregistré ?</a>
        <button class="btn btn-primary" type="submit">Envoyer</button></div>
        @csrf
    </form>
</div>
@endsection
