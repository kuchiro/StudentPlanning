@extends('modele')

@section('title','Confirmation de la suppression association')

@section('contents')
    <p>Voulez-vous supprimer ?</p>
    <form action="{{route('associationSupprimer',['cours_id'=>$cours_etudiant->cours_id,'etudiants'=>$cours_etudiant->etudiant_id])}}" method="post">
        <input type="submit" value="Oui" name="confirmation">
        <input type="submit" value="Non" name="confirmation">
        @csrf
    </form>
@endsection
