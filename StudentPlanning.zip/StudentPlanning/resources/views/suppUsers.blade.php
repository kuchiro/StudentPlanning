@extends('modele')

@section('title','Supprimer un utilisateur')

@section('contents')
    <p>Voulez-vous supprimer {{$users->nom}} ?</p>
    <form action="{{route('suppUser',['id'=>$users->id])}}" method="post">
        <input type="submit" value="Oui" name="confirmation">
        <input type="submit" value="Non" name="confirmation">
        @csrf
    </form>
@endsection
